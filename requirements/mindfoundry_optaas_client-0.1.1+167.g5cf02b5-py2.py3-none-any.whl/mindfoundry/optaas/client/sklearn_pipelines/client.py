import copy
from typing import List, Tuple, Any

from sklearn import clone
from sklearn.pipeline import Pipeline

from mindfoundry.optaas.client.client import OPTaaSClient, Goal
from mindfoundry.optaas.client.sklearn_pipelines.converter import get_converter
from mindfoundry.optaas.client.task import Configuration, Task
from mindfoundry.optaas.client.utils import move_dict_value_up_one_level


class SklearnTask(Task):
    """A Task that can convert a :class:`.Configuration` into a sklearn :class:`.Pipeline`"""

    def __init__(self, task: Task, estimators: List[Tuple]):
        self._estimators = estimators
        super().__init__(task.json, task._session)

    def make_pipeline(self, configuration: Configuration) -> Pipeline:
        """Creates a sklearn :class:`.Pipeline` and sets its parameters based on the provided :class:`.Configuration`"""
        cloned_estimators = [(name, clone(estimator)) for name, estimator in self._estimators]
        configuration_values = self._get_flattened_configuration_values(configuration)
        pipeline = Pipeline(cloned_estimators)
        pipeline.set_params(**configuration_values)
        return pipeline

    def _get_flattened_configuration_values(self, configuration):
        configuration_values = copy.deepcopy(configuration.values)
        for parameter in self.parameters:
            name = parameter['name']
            value = configuration_values.get(name)
            if value is not None:
                if parameter['type'] == 'choice':
                    move_dict_value_up_one_level(configuration_values, name)
                elif parameter['type'] == 'group':
                    configuration_values[name] = list(value.values())
        return configuration_values


class OPTaaSSklearnClient(OPTaaSClient):
    """Allows you to create a Task that can optimize a sklearn pipeline"""

    def create_sklearn_task(self, title: str, estimators: List[Tuple],
                            random_seed: int = None, max_wait_time: float = None, initial_configurations: int = None,
                            goal: Goal = None, user_defined_data: Any = None,
                            **kwargs) -> SklearnTask:
        """Creates a new :class:`.SklearnTask` by making a POST request to OPTaaS

        All the arguments from :meth:`.OPTaaSClient.create_task` can be used here except `parameters` and `constraints`
        because they will be generated from the `estimators`.

        Args:
            estimators (List[Tuple]): List of (name, estimator) tuples as you would provide when creating a sklearn :class:`.Pipeline`
            kwargs: Additional arguments required to optimize certain estimators, e.g. `feature_count`
                (number of features in your data set, required to optimize :class:`.PCA`)

        Returns:
            A new :class:`.SklearnTask`

        Raises:
            :class:`.MissingArgumentError` if a required argument is missing from `kwargs`.
            :class:`.OPTaaSError` if the Task data is invalid or the server is unavailable.
        """
        parameters = []
        constraints = []
        for name, estimator in estimators:
            converter = get_converter(name, estimator)
            p, c = converter.make_parameters_and_constraints(**kwargs)
            parameters.extend(p)
            constraints.extend(c)

        task = self.create_task(title=title, parameters=parameters, constraints=constraints,
                                random_seed=random_seed, max_wait_time=max_wait_time, goal=goal,
                                initial_configurations=initial_configurations, user_defined_data=user_defined_data)
        return SklearnTask(task, estimators)

    def get_sklearn_task(self, task_id: str, estimators: List[Tuple]) -> SklearnTask:
        """Retrieves a stored :class:`.SklearnTask` by making a GET request to OPTaaS.

        This allows you to create a SklearnTask and then use it again in a separate/later session, assuming of course
        that you call this method with the same `estimators` you used to create the original task.

        Args:
            task_id (str): unique id for the Task
            estimators (List[Tuple]): The same list used when calling :meth:`.OPTaaSSklearnClient.create_sklearn_task`

        Returns:
            A :class:`.SklearnTask`

        Raises:
            :class:`.OPTaaSError` if no record is found with the given id or the server is unavailable.
        """
        task = self.get_task(task_id)
        return SklearnTask(task, estimators)
