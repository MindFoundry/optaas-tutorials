from abc import ABC, abstractmethod
from typing import Type, Tuple, List, Any

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import Parameter, ChoiceParameter, IntParameter, FloatParameter, \
    CategoricalParameter, ConstantParameter

ParametersAndConstraints = Tuple[List[Parameter], List[Constraint]]


class MissingArgumentError(ValueError):
    """Raised when a required argument is missing from kwargs in :meth:`.OPTaaSSklearnClient.create_sklearn_task`"""

    def __init__(self, required_arg: str, estimator_type):
        super().__init__(f"{required_arg} is required in kwargs in order to optimize {estimator_type.__name__}")


class SklearnConverter(ABC):
    """Converts a sklearn estimator to a list of OPTaaS :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>`."""

    def __init__(self, estimator_name: str, estimator):
        self._estimator_name = estimator_name
        self._defaults = {key: value for key, value in estimator.get_params().items() if value is not None}

    @abstractmethod
    def make_parameters_and_constraints(self, **kwargs) -> ParametersAndConstraints:
        """Abstract method that should generate the :class:`Parameters <.Parameter>` and
        :class:`Constraints <.Constraint>` required to optimize a sklearn estimator.

        When implementing this method, make sure to call :meth:`.make_parameter` to create parameters
        instead of calling the constructors directly.

        Args:
            kwargs: Additional arguments required to optimize certain estimators, e.g. `feature_count`
                (number of features in your data set, required to optimize :class:`.PCA`)

        Returns:
            A tuple of 2 lists (:class:`Parameters <.Parameter>`, :class:`Constraints <.Constraint>`)

        Raises:
            :class:`.MissingArgumentError` if a required argument is missing from `kwargs`.
        """
        pass

    @property
    @abstractmethod
    def estimator_type(self):
        """The type of estimator that can be optimized by using this class."""
        pass

    def make_parameter(self, parameter_type: Type[Parameter], name: str, **kwargs) -> Parameter:
        """Creates a parameter so as to facilitate the generation of a sklearn Pipeline from a :class:`.Configuration`.

        Args:
            parameter_type (Type[Parameter]): The specific Parameter subclass of the parameter you want to create, e.g. :class:`.IntParameter`.
            name (str): Name to be assigned to the parameter.
                This will be prefixed with the estimator name and `__` to allow `pipeline.set_params` to be called with the configuration values.
            kwargs: Any additional arguments for the parameter constructor, e.g. `minimum`, `maximum`, `choices` etc.
                You don't need to include `id` because one will be generated from the parameter name (any spaces will be replaced by underscores).
                You can include `default`, but this will be overridden if the estimator specifies its own default in `estimator.get_params()`.
        """
        name_with_prefix = self._estimator_name + '__' + name
        kwargs['id'] = name_with_prefix.replace(' ', '_')
        kwargs['name'] = name_with_prefix

        default = self._defaults.get(name)
        if default is None:
            kwargs.pop('default', None)
            if kwargs.get('optional') is True:
                kwargs['include_in_default'] = False
        else:
            if parameter_type == ChoiceParameter:
                default_choice = self._get_default_choice(default, kwargs)
                setattr(default_choice, 'default', default)
                if hasattr(default_choice, 'includeInDefault'):
                    delattr(default_choice, 'includeInDefault')
                default = default_choice

            kwargs.pop('include_in_default', None)
            kwargs['default'] = default

        return parameter_type(**kwargs)

    def _get_default_choice(self, default_value, kwargs) -> Parameter:
        for choice in kwargs['choices']:
            if choice.is_compatible_value(default_value):
                return choice
        raise ValueError(f"{default_value} is not a valid default value for parameter '{kwargs['name']}'")

    def _get_kwarg(self, kwargs, arg_name: str) -> Any:
        if arg_name not in kwargs:
            raise MissingArgumentError(arg_name, self.estimator_type)
        return kwargs[arg_name]


def get_converter(estimator_name: str, estimator) -> SklearnConverter:
    """Returns a converter that can be used to optimize an estimator of the given type."""

    from mindfoundry.optaas.client.sklearn_pipelines.linear_svc import LinearSVCConverter
    from mindfoundry.optaas.client.sklearn_pipelines.pca import PCAConverter
    from mindfoundry.optaas.client.sklearn_pipelines.random_forest_extra_trees import RandomForestConverter, \
        ExtraTreesConverter
    from mindfoundry.optaas.client.sklearn_pipelines.voting import VotingConverter

    predefined_converters = [
        PCAConverter, LinearSVCConverter, RandomForestConverter, ExtraTreesConverter, VotingConverter
    ]

    estimator_type = type(estimator)
    for converter in predefined_converters:
        if issubclass(estimator_type, converter.estimator_type):
            return converter(estimator_name, estimator)
    raise ValueError(f"Estimator type '{estimator_type.__name__}' is not supported")
