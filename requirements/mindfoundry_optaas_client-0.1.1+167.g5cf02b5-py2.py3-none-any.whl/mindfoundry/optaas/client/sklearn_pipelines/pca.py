from typing import Tuple

import numpy
from sklearn.decomposition import PCA

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import Parameter, ChoiceParameter, IntParameter, FloatParameter, \
    CategoricalParameter, BoolParameter, ConstantParameter
from mindfoundry.optaas.client.sklearn_pipelines.converter import SklearnConverter, ParametersAndConstraints


class PCAConverter(SklearnConverter):
    """Converter that allows us to optimize :class:`.PCA` estimators."""

    estimator_type = PCA

    def make_parameters_and_constraints(self, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize a :class:`.PCA` estimator."""

        feature_count = self._get_kwarg(kwargs, 'feature_count')
        mle = self.make_parameter(ConstantParameter, 'n_components_mle', value='mle')
        n_components_int = self.make_parameter(IntParameter, 'n_components_int', minimum=1, maximum=feature_count)
        n_components_float = self.make_parameter(FloatParameter, 'n_components_float',
                                                 minimum=numpy.nextafter(0.0, 1), maximum=numpy.nextafter(1.0, 0))
        n_components = self.make_parameter(ChoiceParameter, 'n_components', optional=True,
                                           choices=[n_components_int, n_components_float, mle])

        svd_solver = self.make_parameter(CategoricalParameter, "svd_solver",
                                         values=['arpack', 'auto', 'full', 'randomized'])
        whiten = self.make_parameter(BoolParameter, 'whiten')
        tol = self.make_parameter(FloatParameter, 'tol', minimum=0, maximum=1, optional=True, include_in_default=False)

        if self._defaults.get('iterated_power') == 'auto':
            del self._defaults['iterated_power']  # excluding the parameter from default is equivalent to 'auto'
        iterated_power = self.make_parameter(IntParameter, 'iterated_power', minimum=0, maximum=99, optional=True,
                                             include_in_default=False)

        return [svd_solver, n_components, whiten, tol, iterated_power], [
            Constraint(when=svd_solver == 'arpack', then=n_components_int < feature_count),
            Constraint(when=(svd_solver == 'auto') | (svd_solver == 'randomized'),
                       then=n_components.is_absent() | (n_components == n_components_int))
        ]
