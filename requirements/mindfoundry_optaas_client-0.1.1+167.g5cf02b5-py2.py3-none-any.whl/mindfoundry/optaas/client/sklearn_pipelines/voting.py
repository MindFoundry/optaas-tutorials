from sklearn.ensemble import VotingClassifier

from mindfoundry.optaas.client.parameter import CategoricalParameter, GroupParameter, FloatParameter
from mindfoundry.optaas.client.sklearn_pipelines.converter import SklearnConverter, ParametersAndConstraints, \
    get_converter


class VotingConverter(SklearnConverter):
    """Converter that allows us to optimize :class:`.VotingClassifier` estimators."""

    estimator_type = VotingClassifier

    def __init__(self, estimator_name: str, estimator: VotingClassifier):
        super().__init__(estimator_name, estimator)
        self.sub_converters = [get_converter(self._estimator_name + '__' + estimator_name, estimator)
                               for estimator_name, estimator in estimator.estimators]

    def make_parameters_and_constraints(self, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize a :class:`.VotingClassifier`."""

        parameters = []
        constraints = []
        weights = []

        for i, converter in enumerate(self.sub_converters):
            p, c = converter.make_parameters_and_constraints(**kwargs)
            parameters.extend(p)
            constraints.extend(c)
            weights.append(self.make_parameter(FloatParameter, f'weight_{i}', minimum=0, maximum=1))

        parameters.extend([
            self.make_parameter(CategoricalParameter, 'voting', values=['hard', 'soft']),
            self.make_parameter(GroupParameter, 'weights', items=weights, optional=True)
        ])

        return parameters, constraints
