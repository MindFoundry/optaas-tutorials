from decorator import contextmanager
from sklearn.ensemble import VotingClassifier, RandomForestClassifier
from sklearn.svm import LinearSVC

from mindfoundry.optaas.client.sklearn_pipelines.client import SklearnTask
from tests.utils import MockConfiguration, MockTask, TestCase

loss_value_default = 'squared_hinge'
loss_value_assigned = 'hinge'

random_state_default = None
random_state_assigned = 456

configurations = {
    'blank': {},
    'loss only': {'clf__loss': loss_value_assigned},
    'random_state only': {'clf__random_state': random_state_assigned},
    'both': {'clf__loss': loss_value_assigned, 'clf__random_state': random_state_assigned},
}


class MockSklearnTask(SklearnTask):
    def __init__(self, estimators, **kwargs):
        super().__init__(MockTask(**kwargs), estimators)


class TestMakePipeline(TestCase):
    maxDiff = None

    def test_correct_values_assigned(self):
        self.assertEqual(loss_value_default, LinearSVC().loss)
        self.assertEqual(random_state_default, LinearSVC().random_state)

        self.task = self.create_task()

        with self.use_configuration('both'):
            self.assert_values(loss_value_assigned, random_state_assigned)

    def create_task(self, **kwargs):
        estimators = [('clf', LinearSVC(**kwargs))]
        return MockSklearnTask(estimators)

    @contextmanager
    def use_configuration(self, configuration_key: str):
        with self.subTest(configuration_key):
            configuration = MockConfiguration(values=configurations[configuration_key])
            self.pipeline = self.task.make_pipeline(configuration)
            yield

    def assert_values(self, loss, random_state):
        values = self.pipeline.get_params()
        self.assertEqual(loss, values['clf__loss'])
        self.assertEqual(random_state, values['clf__random_state'])

    def test_initial_values_are_preserved_if_not_assigned(self):
        random_state_initial = 999
        self.task = self.create_task(random_state=random_state_initial)

        with self.use_configuration('blank'):
            self.assert_values(loss_value_default, random_state_initial)

        with self.use_configuration('loss only'):
            self.assert_values(loss_value_assigned, random_state_initial)

        with self.use_configuration('random_state only'):
            self.assert_values(loss_value_default, random_state_assigned)

        with self.use_configuration('both'):
            self.assert_values(loss_value_assigned, random_state_assigned)

    def test_values_from_previous_configurations_are_NOT_preserved(self):
        self.task = self.create_task()

        with self.use_configuration('loss only'):
            self.assert_values(loss_value_assigned, random_state_default)

        with self.use_configuration('random_state only'):
            self.assert_values(loss_value_default, random_state_assigned)

        with self.use_configuration('both'):
            self.assert_values(loss_value_assigned, random_state_assigned)

    def test_mismatched_estimator(self):
        self.task = self.create_task()
        default_pipeline = self.task.make_pipeline(MockConfiguration())

        wrong_estimator_name = 'wrong'
        configuration = MockConfiguration(values={
            wrong_estimator_name + '__loss': loss_value_assigned
        })

        with self.assertRaisesError(ValueError,
                                    f'Invalid parameter {wrong_estimator_name} for estimator {default_pipeline}. '
                                    f'Check the list of available parameters with `estimator.get_params().keys()`.'):
            self.task.make_pipeline(configuration)

    def test_voting_weights_are_in_correct_order(self):
        expected_weights = [0.56, 0.14, 0.75, 0.23, 0.99, 0.88]
        configuration = MockConfiguration(values={
            'voting__weights': {
                'voting__weight_0': expected_weights[0],
                'voting__weight_1': expected_weights[1],
                'voting__weight_2': expected_weights[2],
                'voting__weight_3': expected_weights[3],
                'voting__weight_4': expected_weights[4],
                'voting__weight_5': expected_weights[5],
            }
        })
        task = MockSklearnTask([('voting', VotingClassifier([
            ('rf0', RandomForestClassifier()),
            ('rf1', RandomForestClassifier()),
            ('rf2', RandomForestClassifier()),
            ('rf3', RandomForestClassifier()),
            ('rf4', RandomForestClassifier()),
            ('rf5', RandomForestClassifier()),
        ]))], parameters=[{'name': 'voting__weights', 'type': 'group'}])
        pipe = task.make_pipeline(configuration)
        self.assertEqual(expected_weights, pipe.get_params()['voting__weights'])
