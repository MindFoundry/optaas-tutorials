from sklearn.svm import LinearSVC

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import FloatParameter, CategoricalParameter, BoolParameter, Distribution, \
    ConstantParameter
from mindfoundry.optaas.client.sklearn_pipelines.converter import SklearnConverter, ParametersAndConstraints


class LinearSVCConverter(SklearnConverter):
    """Converter that allows us to optimize :class:`.LinearSVC` estimators."""

    estimator_type = LinearSVC

    def make_parameters_and_constraints(self, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize a :class:`.LinearSVC` estimator."""

        dual = self.make_parameter(BoolParameter, 'dual', optional=True)
        penalty = self.make_parameter(CategoricalParameter, 'penalty', values=['l1', 'l2'], optional=True)
        loss = self.make_parameter(CategoricalParameter, 'loss', values=['hinge', 'squared_hinge'], optional=True)
        multi_class = self.make_parameter(CategoricalParameter, 'multi_class', values=['ovr', 'crammer_singer'])
        fit_intercept = self.make_parameter(BoolParameter, 'fit_intercept')
        intercept_scaling = self.make_parameter(FloatParameter, 'intercept_scaling', minimum=0, maximum=1,
                                                optional=True)

        parameters = [
            dual, penalty, loss, multi_class, fit_intercept, intercept_scaling,
            self.make_parameter(FloatParameter, 'C', minimum=0.2, maximum=5.0, distribution=Distribution.LOGUNIFORM),
            self.make_parameter(FloatParameter, 'tol', minimum=0, maximum=1),
            self.make_parameter(ConstantParameter, 'class_weight', value='balanced', optional=True),
        ]

        dual_penalty_and_loss_are_present = dual.is_present() & penalty.is_present() & loss.is_present()
        dual_penalty_and_loss_are_absent = dual.is_absent() & penalty.is_absent() & loss.is_absent()

        constraints = [
            Constraint(when=dual == True, then=penalty == 'l2'),
            Constraint(when=dual == False, then=loss == 'squared_hinge'),
            Constraint(when=multi_class == 'ovr', then=dual_penalty_and_loss_are_present),
            Constraint(when=multi_class == 'crammer_singer', then=dual_penalty_and_loss_are_absent),
            Constraint(when=fit_intercept == False, then=intercept_scaling.is_absent()),
        ]

        return parameters, constraints
