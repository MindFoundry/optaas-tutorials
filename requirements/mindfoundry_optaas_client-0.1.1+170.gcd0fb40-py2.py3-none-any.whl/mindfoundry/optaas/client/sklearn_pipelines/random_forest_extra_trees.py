from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import ChoiceParameter, IntParameter, FloatParameter, CategoricalParameter, \
    BoolParameter, Distribution
from mindfoundry.optaas.client.sklearn_pipelines.converter import SklearnConverter, ParametersAndConstraints


class SklearnForestConverter(SklearnConverter):
    """Superclass of converters for :class:`.RandomForestClassifier` and :class:`.ExtraTreesClassifier` estimators."""

    def __init__(self, estimator_name: str, estimator,
                 min_samples_split_distribution: Distribution, max_depth_distribution: Distribution):
        super().__init__(estimator_name, estimator)
        self._min_samples_split_distribution = min_samples_split_distribution
        self._max_depth_distribution = max_depth_distribution

    def make_parameters_and_constraints(self, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize
        a :class:`.RandomForestClassifier` or :class:`.ExtraTreesClassifier`."""

        bootstrap = self.make_parameter(BoolParameter, 'bootstrap')
        oob_score = self.make_parameter(BoolParameter, 'oob_score')
        oob_constraint = Constraint(when=bootstrap == False, then=oob_score != True)

        max_features_float = self.make_parameter(FloatParameter, 'max_features_float', minimum=0.0, maximum=1.0)
        max_features_string = self.make_parameter(CategoricalParameter, 'max_features_string',
                                                  values=['auto', 'sqrt', 'log2'])
        max_features = self.make_parameter(ChoiceParameter, 'max_features',
                                           choices=[max_features_float, max_features_string])

        parameters = [
            bootstrap, oob_score, max_features,
            self.make_parameter(IntParameter, 'n_estimators', minimum=10, maximum=100,
                                distribution=Distribution.LOGUNIFORM),
            self.make_parameter(CategoricalParameter, 'criterion', values=['gini', 'entropy']),
            self.make_parameter(IntParameter, 'min_samples_split', minimum=2, maximum=20,
                                distribution=self._min_samples_split_distribution),
            self.make_parameter(IntParameter, 'min_samples_leaf', minimum=1, maximum=20),
            self.make_parameter(IntParameter, 'max_leaf_nodes', minimum=10, maximum=10000, optional=True,
                                distribution=Distribution.LOGUNIFORM),
            self.make_parameter(IntParameter, 'max_depth', minimum=1, maximum=100, optional=True,
                                distribution=self._max_depth_distribution),
            self.make_parameter(FloatParameter, 'min_weight_fraction_leaf', minimum=0.0, maximum=0.5),
            self.make_parameter(FloatParameter, 'min_impurity_decrease', minimum=0, maximum=1),
        ]
        return parameters, [oob_constraint]


class RandomForestConverter(SklearnForestConverter):
    """Converter that allows us to optimize :class:`.RandomForestClassifier` estimators."""

    estimator_type = RandomForestClassifier

    def __init__(self, estimator_name: str, estimator):
        super().__init__(estimator_name, estimator,
                         min_samples_split_distribution=Distribution.UNIFORM,
                         max_depth_distribution=Distribution.LOGUNIFORM)


class ExtraTreesConverter(SklearnForestConverter):
    """Converter that allows us to optimize :class:`.ExtraTreesClassifier` estimators."""

    estimator_type = ExtraTreesClassifier

    def __init__(self, estimator_name: str, estimator):
        super().__init__(estimator_name, estimator,
                         min_samples_split_distribution=Distribution.LOGUNIFORM,
                         max_depth_distribution=Distribution.UNIFORM)
