from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, VotingClassifier
from sklearn.svm import LinearSVC

from tests.sklearn_pipelines.utils import SklearnTest


class TestEndToEnd(SklearnTest):
    def test_PCA_and_SVC(self):
        self.optimize_pipeline([
            ('reduce_dim', PCA()),
            ('clf', LinearSVC())
        ])

    def test_Voting_with_RandomForest_and_ExtraTrees(self):
        self.optimize_pipeline([
            ('vt', VotingClassifier([
                ('rf', RandomForestClassifier()),
                ('et', ExtraTreesClassifier())
            ]))
        ])
