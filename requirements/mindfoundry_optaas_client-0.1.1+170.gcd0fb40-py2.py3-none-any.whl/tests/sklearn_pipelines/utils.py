import traceback

from sklearn import datasets
from sklearn.model_selection import cross_val_score

from mindfoundry.optaas.client.sklearn_pipelines.client import OPTaaSSklearnClient
from tests.utils import ClientTest


class SklearnTest(ClientTest):
    client_type = OPTaaSSklearnClient
    number_of_iterations = 10
    expected_best_score = 0.94

    def setUp(self):
        super().setUp()
        iris = datasets.load_iris()
        self.data = iris.data
        self.target = iris.target
        self.feature_count = len(iris.feature_names)

    def optimize_pipeline(self, estimators):
        task = self.create_task(estimators)

        configuration = task.generate_configuration()
        for _ in range(self.number_of_iterations):
            score = self.calculate_score(task, configuration)
            configuration = task.record_result(configuration, score)

        final_configuration_score = self.calculate_score(task, configuration)
        best_result, best_configuration = task.get_best_result_and_configuration()
        best_score = max(best_result.score, final_configuration_score)
        self.assertGreaterEqual(best_score, self.expected_best_score)

    def create_task(self, estimators):
        task_title = '_'.join(name for name, estimator in estimators)
        return self.client.create_sklearn_task(title=task_title, estimators=estimators,
                                               feature_count=self.feature_count)

    def calculate_score(self, task, configuration):
        try:
            pipeline = task.make_pipeline(configuration)
            scores = cross_val_score(pipeline, self.data, self.target, scoring='f1_micro')
            return scores.mean()
        except:
            traceback.print_exc()
            self.fail(f'Error with configuration: {configuration}')
