import warnings
from abc import ABC, abstractmethod
from typing import Tuple, List, Any

from sklearn.base import BaseEstimator

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import Parameter
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker

ParametersAndConstraints = Tuple[List[Parameter], List[Constraint]]


class MissingArgumentError(ValueError):
    """Raised when a required argument is missing from kwargs in :meth:`.OPTaaSClient.create_sklearn_task`"""

    def __init__(self, required_arg: str, estimator):
        super().__init__(f"{required_arg} is required in kwargs in order to optimize {type(estimator).__name__}")


class OptimizableBaseEstimator(ABC, BaseEstimator):
    """Mixin that allows an estimator to be optimized by OPTaaS. Subclasses must implement `make_parameters_and_constraints`."""

    @abstractmethod
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Abstract method that should generate the :class:`Parameters <.Parameter>` and
        :class:`Constraints <.Constraint>` required to optimize a sklearn estimator.

        When implementing this method, make sure to use the :class:`SklearnParameterMaker` `sk` to create parameters
        e.g. call `sk.IntParameter(...)` instead of `IntParameter(...)`.

        If the parameter you want to optimize can take values of different types, use a :meth:`ChoiceParameter <.SklearnParameterMaker.ChoiceParameter>`.
        For an example, see `n_components` in :class:`.PCA`. If the parameter value needs to be a list or array, use a
        :meth:`GroupParameter <.SklearnParameterMaker.GroupParameter>`. For an example, see `weights` in :class:`.VotingClassifier`.

        Args:
            sk (SklearnParameterMaker): Allows you to create parameters with the correct names and defaults.
            kwargs: Additional arguments required to optimize certain estimators, e.g. `feature_count`
                (number of features in your data set, required to optimize :class:`.PCA`)

        Returns:
            A tuple of 2 lists (:class:`Parameters <.Parameter>`, :class:`Constraints <.Constraint>`)

        Raises:
            :class:`.MissingArgumentError` if a required argument is missing from `kwargs`.
        """
        pass

    def _get_required_kwarg(self, kwargs, arg_name: str) -> Any:
        if arg_name not in kwargs:
            raise MissingArgumentError(arg_name, self)
        return kwargs[arg_name]


def get_all_parameters_and_constraints(estimators: List[Tuple[str, BaseEstimator]],
                                       **kwargs) -> ParametersAndConstraints:
    """Generate the :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` for all listed estimators.

    Display a warning for each estimator that is not optimizable (i.e. does not extend :class:`.OptimizableBaseEstimator`).

    Args:
        estimators (List[Tuple[str, BaseEstimator]): List of (name, estimator) tuples as you would provide when creating a sklearn :class:`.Pipeline`.
        kwargs: Additional arguments required to optimize certain estimators, e.g. :class:`.PCA` requires `feature_count`.

    Returns:
        A tuple of 2 lists (:class:`Parameters <.Parameter>`, :class:`Constraints <.Constraint>`)

    Raises:
        :class:`.MissingArgumentError` if a required argument is missing from `kwargs`.
    """

    parameters = []
    constraints = []
    for estimator_name, estimator in estimators:
        if isinstance(estimator, OptimizableBaseEstimator):
            parameter_maker = SklearnParameterMaker(estimator_name, estimator)
            p, c = estimator.make_parameters_and_constraints(parameter_maker, **kwargs)
            parameters.extend(p)
            constraints.extend(c)
        else:
            warnings.warn(f"Estimator ('{estimator_name}', {type(estimator).__name__}) is not optimizable "
                          f"(not instance of OptimizableBaseEstimator).")
    return parameters, constraints
