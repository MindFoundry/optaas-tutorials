from sklearn.ensemble import RandomForestClassifier as BaseRandomForestClassifier, \
    ExtraTreesClassifier as BaseExtraTreesClassifier
from sklearn.ensemble.forest import ForestClassifier

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import Distribution
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator, ParametersAndConstraints
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker


class OptimizableForestClassifier(OptimizableBaseEstimator, ForestClassifier):
    """Superclass of converters for :class:`.RandomForestClassifier` and :class:`.ExtraTreesClassifier` estimators."""

    def make_forest_parameters_and_constraints(self, sk: SklearnParameterMaker,
                                               min_samples_split_distribution: Distribution,
                                               max_depth_distribution: Distribution,
                                               **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize
        a :class:`.RandomForestClassifier` or :class:`.ExtraTreesClassifier`."""

        bootstrap = sk.BoolParameter('bootstrap')
        oob_score = sk.BoolParameter('oob_score')
        oob_constraint = Constraint(when=bootstrap == False, then=oob_score != True)

        max_features_float = sk.FloatParameter('max_features_float', minimum=0.0, maximum=1.0)
        max_features_string = sk.CategoricalParameter('max_features_string',
                                                      values=['auto', 'sqrt', 'log2'])
        max_features = sk.ChoiceParameter('max_features',
                                          choices=[max_features_float, max_features_string])

        parameters = [
            bootstrap, oob_score, max_features,
            sk.IntParameter('n_estimators', minimum=10, maximum=100, distribution=Distribution.LOGUNIFORM),
            sk.CategoricalParameter('criterion', values=['gini', 'entropy']),
            sk.IntParameter('min_samples_split', minimum=2, maximum=20, distribution=min_samples_split_distribution),
            sk.IntParameter('min_samples_leaf', minimum=1, maximum=20),
            sk.IntParameter('max_leaf_nodes', minimum=10, maximum=10000, optional=True,
                            distribution=Distribution.LOGUNIFORM),
            sk.IntParameter('max_depth', minimum=1, maximum=100, optional=True, distribution=max_depth_distribution),
            sk.FloatParameter('min_weight_fraction_leaf', minimum=0.0, maximum=0.5),
            sk.FloatParameter('min_impurity_decrease', minimum=0, maximum=1),
        ]
        return parameters, [oob_constraint]


class RandomForestClassifier(OptimizableForestClassifier, BaseRandomForestClassifier):
    """Allows us to optimize :class:`.RandomForestClassifier` estimators."""

    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        return self.make_forest_parameters_and_constraints(sk,
                                                           min_samples_split_distribution=Distribution.UNIFORM,
                                                           max_depth_distribution=Distribution.LOGUNIFORM,
                                                           **kwargs)


class ExtraTreesClassifier(OptimizableForestClassifier, BaseExtraTreesClassifier):
    """Allows us to optimize :class:`.ExtraTreesClassifier` estimators."""

    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        return self.make_forest_parameters_and_constraints(sk,
                                                           min_samples_split_distribution=Distribution.LOGUNIFORM,
                                                           max_depth_distribution=Distribution.UNIFORM,
                                                           **kwargs)
