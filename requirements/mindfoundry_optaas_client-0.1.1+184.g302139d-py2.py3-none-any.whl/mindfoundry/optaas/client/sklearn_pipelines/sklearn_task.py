import copy
from typing import List, Tuple, Dict

from sklearn import clone
from sklearn.base import BaseEstimator
from sklearn.pipeline import Pipeline

from mindfoundry.optaas.client.task import Configuration, Task
from mindfoundry.optaas.client.utils import move_dict_value_up_one_level


class SklearnTask(Task):
    """A Task that can convert a :class:`.Configuration` into a sklearn :class:`.Pipeline`"""

    def __init__(self, task: Task, estimators: List[Tuple[str, BaseEstimator]]):
        self._estimators = estimators
        super().__init__(task.json, task._session)

    def make_pipeline(self, configuration: Configuration) -> Pipeline:
        """Creates a sklearn :class:`.Pipeline` and sets its parameters based on the provided :class:`.Configuration`"""
        cloned_estimators = [(name, clone(estimator)) for name, estimator in self._estimators]
        configuration_values = self._get_flattened_configuration_values(configuration)
        pipeline = Pipeline(cloned_estimators)
        pipeline.set_params(**configuration_values)
        return pipeline

    def _get_flattened_configuration_values(self, configuration: Configuration) -> Dict:
        configuration_values = copy.deepcopy(configuration.values)
        for parameter in self.parameters:
            name = parameter['name']
            if name in configuration_values:
                value = configuration_values.get(name)

                if parameter['type'] == 'choice':
                    move_dict_value_up_one_level(configuration_values, name)
                elif parameter['type'] == 'group':
                    configuration_values[name] = list(value.values())
            else:
                configuration_values[name] = None
        return configuration_values
