from decorator import contextmanager

from mindfoundry.optaas.client.client import Goal
from mindfoundry.optaas.client.parameter import IntParameter, ConstantParameter, FloatParameter
from mindfoundry.optaas.client.sklearn_pipelines.linear_svc import LinearSVC
from mindfoundry.optaas.client.sklearn_pipelines.mixin import MissingArgumentError
from mindfoundry.optaas.client.sklearn_pipelines.pca import PCA
from mindfoundry.optaas.client.sklearn_pipelines.random_forest_extra_trees import RandomForestClassifier, \
    ExtraTreesClassifier
from mindfoundry.optaas.client.sklearn_pipelines.voting import VotingClassifier
from tests.sklearn_pipelines.utils import SklearnTest, MockClientTest


class TestCreate(SklearnTest):
    def test_create_sklearn_task(self):
        estimators = [
            ('reduce_dim', PCA(whiten=True, n_components=2)),
            ('clf', LinearSVC(penalty='l1', dual=False, tol=0.3))
        ]
        user_defined_data = [{
            'my': 'data',
            'here': [1, 2, 3]
        }, 'a', 'b', 'c']
        task = self.client.create_sklearn_task(title='Sklearn Test', estimators=estimators, feature_count=9,
                                               random_seed=123, max_wait_time=4, initial_configurations=7,
                                               goal=Goal.max, user_defined_data=user_defined_data)

        task.refresh()
        self.assertEqual(0, task.number_of_iterations)
        self.assertEqual(user_defined_data, task.user_defined_data)
        self.assertEqual('running', task.status)


class TestResume(SklearnTest):
    def test_resume_sklearn_task(self):
        estimators = [
            ('vt', VotingClassifier([
                ('rf', RandomForestClassifier()),
                ('et', ExtraTreesClassifier())
            ]))
        ]
        task = self.create_task(estimators)

        configuration = task.generate_configuration()
        score = self.calculate_score(task, configuration)

        resumed_task = self.client.get_sklearn_task(task.id, estimators)
        next_configuration = resumed_task.record_result(configuration, score)
        next_score = self.calculate_score(resumed_task, next_configuration)
        resumed_task.record_result(next_configuration, next_score)

        resumed_task.refresh()
        self.assertEqual(2, resumed_task.number_of_iterations)
        self.assertEqual('running', resumed_task.status)


class TestDefaults(MockClientTest):
    def test_no_defaults_specified(self):
        with self.use_estimators(PCA(), LinearSVC()):
            self.assert_n_components_default(None)
            self.assert_tol_default(0.0001)

    @contextmanager
    def use_estimators(self, pca, svc=None):
        estimators = [('rd', pca)]
        if svc:
            estimators.append(('svc', svc))
        self.task = self.create_mock_task(estimators, feature_count=100, unrelated_arg='abc')
        yield

    def assert_n_components_default(self, expected_default, expected_type=None):
        with self.subTest('n_components'):
            n_components_choice = next(p for p in self.task.parameters if p['name'] == 'rd__n_components')
            if expected_default is None:
                self.assertFalse(n_components_choice['includeInDefault'])
            else:
                self.assertTrue(n_components_choice['default'].startswith('#'))
                n_components_default_id = n_components_choice['default'][1:]
                n_components = next(p for p in n_components_choice['choices'] if p['id'] == n_components_default_id)

                self.assertEqual(expected_type, n_components['type'])
                if expected_type == 'constant':
                    self.assertEqual(expected_default, n_components['value'])
                    self.assertNotIn('default', n_components)
                else:
                    self.assertEqual(expected_default, n_components['default'])

    def assert_tol_default(self, expected_default):
        with self.subTest('tol'):
            tol = next(p for p in self.task.parameters if p['name'] == 'svc__tol')
            self.assertEqual(expected_default, tol['default'])

    def test_n_components_int_and_tol(self):
        with self.use_estimators(PCA(n_components=7), LinearSVC(tol=0.123)):
            self.assert_n_components_default(7, 'integer')
            self.assert_tol_default(0.123)

    def test_n_components_float(self):
        with self.use_estimators(PCA(n_components=0.123)):
            self.assert_n_components_default(0.123, 'number')

    def test_n_components_mle(self):
        with self.use_estimators(PCA(n_components='mle')):
            self.assert_n_components_default('mle', 'constant')

    def test_n_components_invalid(self):
        with self.assertRaisesRegex(ValueError,
                                    "invalid_string is not a valid default value for parameter 'pca__n_components'"):
            self.create_mock_task([('pca', PCA(n_components='invalid_string'))], feature_count=9)


class TestValidation(MockClientTest):
    def test_PCA_without_feature_count(self):
        estimators = [('reduce_dim', PCA())]
        with self.assertRaisesRegex(MissingArgumentError,
                                    "feature_count is required in kwargs in order to optimize PCA"):
            self.create_mock_task(estimators)

    def test_space_in_estimator_name_is_converted_to_underscore_for_id(self):
        estimators = [('random forest', RandomForestClassifier())]
        task = self.create_mock_task(estimators)
        wrong_ids = [p for p in task.parameters if ' ' in p['id']]
        self.assertEqual(0, len(wrong_ids), f"These ids contain a space: {wrong_ids}")


class TestParameters(MockClientTest):
    excluded_forest_parameters = ['random_state', 'verbose', 'warm_start', 'n_jobs', 'class_weight',
                                  'min_impurity_split']
    excluded_parameters = {
        'pca': ['copy', 'random_state'],
        'svc': ['random_state', 'max_iter', 'verbose'],
        'my_svc': ['random_state', 'max_iter', 'verbose'],
        'rf': excluded_forest_parameters,
        'extr': excluded_forest_parameters,
        'voting': ['vet__' + p for p in excluded_forest_parameters] +
                  ['vrf__' + p for p in excluded_forest_parameters] +
                  ['vet', 'vrf', 'estimators', 'flatten_transform', 'n_jobs']
    }

    def test_all_required_parameters_are_generated_with_correct_names(self):
        estimators = [
            ('pca', PCA()),
            ('svc', LinearSVC()),
            ('rf', RandomForestClassifier()),
            ('extr', ExtraTreesClassifier()),
            ('voting', VotingClassifier([
                ('vrf', RandomForestClassifier()),
                ('vet', ExtraTreesClassifier())
            ])),
        ]
        self.task = self.create_mock_task(estimators, feature_count=5)

        for estimator_name, estimator in estimators:
            with self.subTest(estimator_name):
                self.verify_parameters(estimator_name, estimator)

    def verify_parameters(self, estimator_name, estimator):
        required_parameter_names = {estimator_name + '__' + parameter_name
                                    for parameter_name in estimator.get_params()
                                    if parameter_name not in self.excluded_parameters[estimator_name]}
        generated_parameter_names = {parameter['name'] for parameter in self.task.parameters}
        missing_parameter_names = required_parameter_names - generated_parameter_names
        self.assertEqual(0, len(missing_parameter_names), f'Missing parameters: {missing_parameter_names}')

    def test_estimator_that_extends_predefined_class(self):
        class MyLinearSVC(LinearSVC):
            pass

        estimators = [('my_svc', MyLinearSVC())]
        self.task = self.create_mock_task(estimators)
        self.verify_parameters('my_svc', LinearSVC())

    def test_feature_count_is_used_in_PCA(self):
        feature_count = 999
        estimators = [('pca', PCA())]
        task = self.create_mock_task(estimators, feature_count=feature_count)
        n_components_choice = next(p for p in task.parameters if p['name'] == 'pca__n_components')
        n_components_int = next(p for p in n_components_choice['choices'] if p['name'] == 'pca__n_components_int')
        self.assertEqual(feature_count, n_components_int['maximum'])

    def test_voting_weights(self):
        self.assert_correct_voting_weights('forest only', [
            ('rf', RandomForestClassifier()),
        ])
        self.assert_correct_voting_weights('trees only', [
            ('extr', ExtraTreesClassifier())
        ])
        self.assert_correct_voting_weights('both', [
            ('forest', RandomForestClassifier()),
            ('trees', ExtraTreesClassifier())
        ])

    def assert_correct_voting_weights(self, description, voting_estimators):
        with self.subTest(description):
            estimators = [('voting', VotingClassifier(voting_estimators))]
            task = self.create_mock_task(estimators)
            weights = next(p for p in task.parameters if p['name'] == 'voting__weights')
            self.assertEqual(len(voting_estimators), len(weights['items']))
