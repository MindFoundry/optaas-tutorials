from random import randint

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.sklearn_pipelines.linear_svc import LinearSVC
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator, ParametersAndConstraints
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker
from mindfoundry.optaas.client.sklearn_pipelines.pca import PCA
from mindfoundry.optaas.client.sklearn_pipelines.random_forest_extra_trees import RandomForestClassifier, \
    ExtraTreesClassifier
from mindfoundry.optaas.client.sklearn_pipelines.voting import VotingClassifier
from tests.sklearn_pipelines.utils import SklearnTest


class TestEndToEnd(SklearnTest):
    def test_PCA_and_SVC(self):
        task = self.optimize_pipeline([
            ('reduce_dim', PCA()),
            ('clf', LinearSVC())
        ])

        with self.assertRaisesOPTaaSError(400, "Configuration violates constraint: if #clf__fit_intercept == true "
                                               "then #clf__intercept_scaling is_present"):
            task.add_user_defined_configuration({
                'clf__C': 0.2,
                'clf__fit_intercept': True,
                'clf__multi_class': 'crammer_singer',
                'clf__tol': 0.3,
                'reduce_dim__svd_solver': 'auto',
                'reduce_dim__iterated_power': {'reduce_dim__iterated_power_auto': 'auto'},
                'reduce_dim__whiten': True
            })

        with self.assertRaisesOPTaaSError(400, "Configuration violates constraint: if #clf__fit_intercept == false "
                                               "then #clf__intercept_scaling is_absent"):
            task.add_user_defined_configuration({
                'clf__C': 0.2,
                'clf__fit_intercept': False,
                'clf__intercept_scaling': 0.5,
                'clf__multi_class': 'crammer_singer',
                'clf__tol': 0.3,
                'reduce_dim__svd_solver': 'auto',
                'reduce_dim__iterated_power': {'reduce_dim__iterated_power_auto': 'auto'},
                'reduce_dim__whiten': True
            })

        with self.assertRaisesOPTaaSError(
                400,
                "Configuration violates constraint: if #reduce_dim__svd_solver == 'arpack' "
                "then ( #reduce_dim__n_components_int < 4 ) && #reduce_dim__tol is_present"):
            task.add_user_defined_configuration({
                'clf__C': 0.2,
                'clf__fit_intercept': False,
                'clf__intercept_scaling': 0.5,
                'clf__multi_class': 'crammer_singer',
                'clf__tol': 0.3,
                'reduce_dim__svd_solver': 'arpack',
                'reduce_dim__iterated_power': {'reduce_dim__iterated_power_auto': 'auto'},
                'reduce_dim__n_components': {'reduce_dim__n_components_int': 3},
                'reduce_dim__whiten': True
            })

        with self.assertRaisesOPTaaSError(
                400,
                "Configuration violates constraint: if #reduce_dim__svd_solver == 'arpack' "
                "then ( #reduce_dim__n_components_int < 4 ) && #reduce_dim__tol is_present"):
            task.add_user_defined_configuration({
                'clf__C': 0.2,
                'clf__fit_intercept': False,
                'clf__intercept_scaling': 0.5,
                'clf__multi_class': 'crammer_singer',
                'clf__tol': 0.3,
                'reduce_dim__svd_solver': 'arpack',
                'reduce_dim__iterated_power': {'reduce_dim__iterated_power_auto': 'auto'},
                'reduce_dim__n_components': {'reduce_dim__n_components_int': 4},
                'reduce_dim__tol': 0.5,
                'reduce_dim__whiten': True
            })

        self.verify_valid_configuration(task, {
            'clf__C': 0.2,
            'clf__fit_intercept': False,  # False and no intercept_scaling present
            'clf__multi_class': 'crammer_singer',
            'clf__tol': 0.3,
            'reduce_dim__svd_solver': 'auto',
            'reduce_dim__iterated_power': {'reduce_dim__iterated_power_auto': 'auto'},
            'reduce_dim__whiten': True
        })

        self.verify_valid_configuration(task, {
            'clf__C': 0.2,
            'clf__fit_intercept': True,  # True and intercept_scaling present
            'clf__intercept_scaling': 0.5,
            'clf__multi_class': 'crammer_singer',
            'clf__tol': 0.3,
            'reduce_dim__svd_solver': 'auto',
            'reduce_dim__iterated_power': {'reduce_dim__iterated_power_auto': 'auto'},
            'reduce_dim__whiten': True
        })

    def verify_valid_configuration(self, task, values):
        config = task.add_user_defined_configuration(values=values)
        self.assertEqual('user-defined', config.type)
        self.assertEqual(values, config.values)
        self.calculate_score(task, config)

    def test_Voting_with_RandomForest_and_ExtraTrees(self):
        self.optimize_pipeline([
            ('vt', VotingClassifier([
                ('rf', RandomForestClassifier()),
                ('et', ExtraTreesClassifier())
            ]))
        ])

    def test_user_defined(self):
        class UserDefinedEstimator(OptimizableBaseEstimator):
            test = self
            expect_default_configuration = True

            def __init__(self, int_param: int = 3, cat_param: str = None, float_param: float = 0.1,
                         non_optimizable_param=9):
                self.int_param = int_param
                self.cat_param = cat_param
                self.float_param = float_param
                self.non_optimizable_param = non_optimizable_param

            def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
                int_param = sk.IntParameter('int_param', minimum=1, maximum=10)
                float_param = sk.FloatParameter('float_param', minimum=0, maximum=1)
                cat_param = sk.CategoricalParameter('cat_param', values=['a', 'b', 'c', 'd'])
                constraints = [
                    Constraint(when=int_param == 2, then=cat_param != 'a'),
                    Constraint((float_param <= 0.2) | (float_param > 0.32))
                ]
                return [int_param, float_param, cat_param], constraints

            def fit(self, X, y=None, **fit_params):
                self.test.assertEqual(self.non_optimizable_param, 2)

                if UserDefinedEstimator.expect_default_configuration:
                    self.test.assertEqual(self.int_param, 3)
                    self.test.assertEqual(self.float_param, 0.13)
                    self.test.assertEqual(self.cat_param, 'c')
                    UserDefinedEstimator.expect_default_configuration = False
                else:
                    self.test.assertTrue(0 <= self.float_param <= 0.2 or 0.32 < self.float_param <= 1)
                    self.test.assertIn(self.int_param, range(1, 11))
                    if self.int_param == 2:
                        self.test.assertIn(self.cat_param, ['b', 'c', 'd'])
                    else:
                        self.test.assertIn(self.cat_param, ['a', 'b', 'c', 'd'])

                return self

            def predict(self, X):
                return [randint(0, 2) for _ in X]

        self.optimize_pipeline([
            ('user_defined', UserDefinedEstimator(cat_param='c', non_optimizable_param=2, float_param=0.13))
        ], ignore_score=True)
