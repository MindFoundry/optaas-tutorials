import warnings

from sklearn.ensemble import RandomForestClassifier

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator, ParametersAndConstraints
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker
from mindfoundry.optaas.client.sklearn_pipelines.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.random_forest_extra_trees import RandomForestClassifier, \
    BaseRandomForestClassifier
from mindfoundry.optaas.client.sklearn_pipelines.voting import VotingClassifier
from tests.sklearn_pipelines.utils import MockClientTest


def make_test_parameters_and_constraints(sk: SklearnParameterMaker, exclude_value) -> ParametersAndConstraints:
    criterion = sk.CategoricalParameter('criterion', values=['gini', 'entropy'])
    min_samples_split = sk.IntParameter('min_samples_split', minimum=2, maximum=20)
    min_samples_leaf = sk.IntParameter('min_samples_leaf', minimum=1, maximum=20)

    constraint1 = Constraint(when=criterion == 'gini', then=min_samples_split > 5)
    constraint2 = Constraint(min_samples_leaf != exclude_value)
    return [criterion, min_samples_split, min_samples_leaf], [constraint1, constraint2]


expected_parameters = [
    {'name': 'user_defined__criterion', 'id': 'user_defined__criterion', 'type': 'categorical',
     'enum': ['gini', 'entropy'], 'default': 'entropy'},
    {'name': 'user_defined__min_samples_split', 'id': 'user_defined__min_samples_split', 'type': 'integer',
     'minimum': 2, 'maximum': 20, 'default': 3},
    {'name': 'user_defined__min_samples_leaf', 'id': 'user_defined__min_samples_leaf', 'type': 'integer',
     'minimum': 1, 'maximum': 20, 'default': 1},
]

expected_constraints = [
    "if #user_defined__criterion == 'gini' then #user_defined__min_samples_split > 5",
    "#user_defined__min_samples_leaf != 17"
]


class MyEstimator(OptimizableBaseEstimator):
    def __init__(self, criterion, min_samples_split=5, min_samples_leaf=1):
        self.criterion = criterion
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf

    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        return make_test_parameters_and_constraints(sk, self._get_required_kwarg(kwargs, 'exclude_value'))


class MyMixinEstimator(OptimizableBaseEstimator, BaseRandomForestClassifier):
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        return make_test_parameters_and_constraints(sk, self._get_required_kwarg(kwargs, 'exclude_value'))


class MyExtendedEstimator(RandomForestClassifier):
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        return make_test_parameters_and_constraints(sk, self._get_required_kwarg(kwargs, 'exclude_value'))


class TestUserDefined(MockClientTest):
    def test_non_optimizable_estimators_should_be_skipped(self):
        estimators = [
            ('reduce_dim', PCA()),
            ('base_pca', BasePCA()),  # The base (i.e. native sklearn) classes are not optimizable
            ('voting', VotingClassifier([
                ('rf', RandomForestClassifier()),
                ('base_rd', BaseRandomForestClassifier())  # The base (i.e. native sklearn) classes are not optimizable
            ]))
        ]

        expected_warnings = [
            "Estimator ('base_pca', PCA) is not optimizable (not instance of OptimizableBaseEstimator).",
            "Estimator ('voting__base_rd', RandomForestClassifier) is not optimizable (not instance of OptimizableBaseEstimator)."
        ]

        with warnings.catch_warnings(record=True) as caught_warnings:
            self.create_mock_task(estimators, feature_count=5)

        self.assertEqual(expected_warnings, [str(w.message) for w in caught_warnings])

    def test_user_defined_subclass_should_be_optimized(self):
        self.verify_user_defined_estimator(MyEstimator)

    def verify_user_defined_estimator(self, estimator_type):
        estimator = estimator_type(criterion="entropy", min_samples_split=3)
        estimators = [('user_defined', estimator)]

        with warnings.catch_warnings(record=True) as caught_warnings:
            task = self.create_mock_task(estimators, exclude_value=17)

        self.assertEqual(0, len(caught_warnings))
        self.assertEqual(expected_parameters, task.parameters)
        self.assertEqual(expected_constraints, task.constraints)

    def test_user_defined_mixin_should_be_optimized(self):
        self.verify_user_defined_estimator(MyMixinEstimator)

    def test_user_defined_extension_of_predefined_class_should_be_optimized(self):
        self.verify_user_defined_estimator(MyExtendedEstimator)
