from sklearn.ensemble import \
    RandomForestClassifier as BaseRandomForestClassifier, \
    ExtraTreesClassifier as BaseExtraTreesClassifier, \
    RandomForestRegressor as BaseRandomForestRegressor, \
    ExtraTreesRegressor as BaseExtraTreesRegressor

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import Distribution
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator, ParametersAndConstraints
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker


class OptimizableForest(OptimizableBaseEstimator):
    """Superclass for optimizable forest-based estimators."""

    # Properties must be specified in subclasses
    criterion_values = None
    min_samples_split_distribution = None
    max_depth_distribution = None
    min_impurity_decrease_maximum = None

    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize forest-based estimators."""

        bootstrap = sk.BoolParameter('bootstrap')
        oob_score = sk.BoolParameter('oob_score')
        oob_constraint = Constraint(when=bootstrap == False, then=oob_score != True)

        max_features_float = sk.FloatParameter('max_features_float', minimum=0.0, maximum=1.0)
        max_features_string = sk.CategoricalParameter('max_features_string',
                                                      values=['auto', 'sqrt', 'log2'])
        max_features = sk.ChoiceParameter('max_features',
                                          choices=[max_features_float, max_features_string])

        parameters = [
            bootstrap, oob_score, max_features,
            sk.IntParameter('n_estimators', minimum=10, maximum=500, distribution=Distribution.LOGUNIFORM),
            sk.CategoricalParameter('criterion', values=self.criterion_values),
            sk.IntParameter('min_samples_split', minimum=2, maximum=20,
                            distribution=self.min_samples_split_distribution),
            sk.IntParameter('min_samples_leaf', minimum=1, maximum=20),
            sk.IntParameter('max_leaf_nodes', minimum=10, maximum=10000, optional=True,
                            distribution=Distribution.LOGUNIFORM),
            sk.IntParameter('max_depth', minimum=1, maximum=100, optional=True,
                            distribution=self.max_depth_distribution),
            sk.FloatParameter('min_weight_fraction_leaf', minimum=0.0, maximum=0.5),
            sk.FloatParameter('min_impurity_decrease', minimum=0, maximum=self.min_impurity_decrease_maximum),
        ]
        return parameters, [oob_constraint]


class OptimizableForestClassifier(OptimizableForest):
    """Superclass for optimizable forest-based classifiers."""

    criterion_values = ['gini', 'entropy']
    min_impurity_decrease_maximum = 1


class OptimizableForestRegressor(OptimizableForest):
    """Superclass for optimizable forest-based regressors."""

    criterion_values = ['mse', 'mae']
    min_impurity_decrease_maximum = 0.01


class OptimizableRandomForest(OptimizableForest):
    """Superclass for optimizable forest-based classifiers."""

    min_samples_split_distribution = Distribution.UNIFORM
    max_depth_distribution = Distribution.LOGUNIFORM


class OptimizableExtraTrees(OptimizableForest):
    """Allows us to optimize :class:`.ExtraTreesClassifier` estimators."""

    min_samples_split_distribution = Distribution.LOGUNIFORM
    max_depth_distribution = Distribution.UNIFORM


class RandomForestClassifier(BaseRandomForestClassifier, OptimizableForestClassifier, OptimizableRandomForest):
    """Allows us to optimize :class:`.RandomForestClassifier` estimators."""
    pass


class ExtraTreesClassifier(BaseExtraTreesClassifier, OptimizableForestClassifier, OptimizableExtraTrees):
    """Allows us to optimize :class:`.ExtraTreesClassifier` estimators."""
    pass


class RandomForestRegressor(BaseRandomForestRegressor, OptimizableForestRegressor, OptimizableRandomForest):
    """Allows us to optimize :class:`.RandomForestRegressor` estimators."""
    pass


class ExtraTreesRegressor(BaseExtraTreesRegressor, OptimizableForestRegressor, OptimizableExtraTrees):
    """Allows us to optimize :class:`.ExtraTreesRegressor` estimators."""
    pass
