from sklearn.decomposition import FastICA as BaseICA

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator, ParametersAndConstraints
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker


class FastICA(BaseICA, OptimizableBaseEstimator):
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize a :class:`.FastICA` estimator."""

        feature_count = self._get_required_kwarg(kwargs, 'feature_count')
        n_components = sk.IntParameter('n_components', minimum=1, maximum=feature_count, optional=True)
        whiten = sk.BoolParameter('whiten')

        return [
                   n_components, whiten,
                   sk.FloatParameter('tol', minimum=0, maximum=1),
                   sk.CategoricalParameter('fun', values=["logcosh", "exp", "cube"]),
                   sk.CategoricalParameter('algorithm', values=['parallel', 'deflation'])

               ], [
                   Constraint(when=whiten == False, then=n_components.is_absent())
               ]
