from sklearn.ensemble import VotingClassifier as BaseVotingClassifier

from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator, ParametersAndConstraints, \
    get_all_parameters_and_constraints
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker


class VotingClassifier(BaseVotingClassifier, OptimizableBaseEstimator):
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize a :class:`.VotingClassifier`."""

        grouped_parameters, constraints = get_all_parameters_and_constraints([
            (sk.prefix + estimator_name, estimator) for estimator_name, estimator in self.estimators
        ])

        parameters = [p for group in grouped_parameters for p in group.items]

        for parameter in parameters:
            parameter.name = parameter.id.replace(sk.prefix, '', 1)

        parameters.extend([
            sk.CategoricalParameter('voting', values=['hard', 'soft']),
            sk.GroupParameter('weights', optional=True, items=[
                sk.FloatParameter(f'weight_{estimator_name}', minimum=0, maximum=1)
                for estimator_name, _ in self.estimators
            ])
        ])

        return parameters, constraints
