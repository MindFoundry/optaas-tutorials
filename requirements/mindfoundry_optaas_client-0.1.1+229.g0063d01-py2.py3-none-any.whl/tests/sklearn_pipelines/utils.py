import traceback
from unittest import TestCase

from sklearn import datasets
from sklearn.model_selection import cross_val_score

from mindfoundry.optaas.client.client import OPTaaSClient
from tests.utils import ClientTest, MockTask


class SklearnTest(ClientTest):
    number_of_iterations = 8
    print_scores = False
    expected_best_non_default_score = 0.7
    scoring = 'f1_micro'
    dataset = datasets.load_iris()

    def setUp(self):
        super().setUp()
        self.data = self.dataset.data
        self.target = self.dataset.target
        self.feature_count = len(self.dataset.feature_names)

    def optimize_pipeline(self, estimators, ignore_score=False):
        task = self.create_task(estimators)

        configuration = task.generate_configuration()
        score = self.calculate_score(task, configuration)
        if self.print_scores:
            print(f'Default score: {score}')

        non_default_scores = []
        for _ in range(self.number_of_iterations):
            configuration = task.record_result(configuration, score)
            score = self.calculate_score(task, configuration)
            if self.print_scores:
                print(f'Score: {score}')
            non_default_scores.append(score)

        best_non_default_score = max(non_default_scores)
        if self.print_scores:
            print(f"Best non-default score: {best_non_default_score}")
        if not ignore_score:
            self.assertGreaterEqual(best_non_default_score, self.expected_best_non_default_score)

        return task

    def create_task(self, estimators):
        task_title = '_'.join(name for name, estimator in estimators)
        return self.client.create_sklearn_task(title=task_title, estimators=estimators,
                                               feature_count=self.feature_count)

    def calculate_score(self, task, configuration, retries=0):
        try:
            pipeline = task.make_pipeline(configuration)
            scores = cross_val_score(pipeline, self.data, self.target, scoring=self.scoring)
            return scores.mean()
        except Exception as err:
            traceback.print_exc()
            if isinstance(err, ValueError) and str(err) == 'array must not contain infs or NaNs':
                print('Ignoring known issue https://github.com/scikit-learn/scikit-learn/issues/2089')
                if retries < 5:
                    return self.calculate_score(task, configuration, retries=retries + 1)
                else:
                    self.fail(f'Too many retries!')
            else:
                self.fail(f'Error with configuration: {configuration}')


class MockClient(OPTaaSClient):
    def __init__(self):
        super().__init__('dummy url', 'dummy api key')

    def create_task(self, **kwargs):
        kwargs['parameters'] = [p.to_json() for p in kwargs['parameters']]
        kwargs['constraints'] = [c.to_optaas_expression() for c in kwargs['constraints']]
        return MockTask(**kwargs)


class MockClientTest(TestCase):
    maxDiff = None

    def setUp(self):
        self.client = MockClient()

    def create_mock_task(self, estimators, **kwargs):
        return self.client.create_sklearn_task(title='Dummy task', estimators=estimators, **kwargs)

    def find_parameter(self, group_name, parameter_name):
        group = next(p for p in self.task.parameters if p['name'] == group_name)
        return next(p for p in group['items'] if p['name'] == parameter_name)
