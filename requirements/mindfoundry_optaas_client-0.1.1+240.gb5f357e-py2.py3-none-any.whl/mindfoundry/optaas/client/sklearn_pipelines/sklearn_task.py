import copy
from typing import List, Tuple, Dict, Union

from sklearn import clone
from sklearn.base import BaseEstimator
from sklearn.pipeline import Pipeline

from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptionalStepMixin, optional_step, OneOf
from mindfoundry.optaas.client.task import Configuration, Task
from mindfoundry.optaas.client.utils import move_dict_value_up_one_level, get_first_key


class SklearnTask(Task):
    """A Task that can convert a :class:`.Configuration` into a sklearn :class:`.Pipeline`"""

    def __init__(self, task: Task, estimators: List[Tuple[str, Union[BaseEstimator, OneOf]]]):
        self._estimators = estimators
        super().__init__(task.json, task._session)

    def make_pipeline(self, configuration: Configuration) -> Pipeline:
        """Creates a sklearn :class:`.Pipeline` and sets its parameters based on the provided :class:`.Configuration`"""

        estimators = []
        values = copy.deepcopy(configuration.values)

        for name, estimator in self._estimators:
            if name in values:
                estimator_parameter = next(p for p in self.parameters if p['name'] == name)

                if isinstance(estimator, OneOf):
                    choice = get_first_key(values[name])
                    choice_index = int(choice[len(name) + 2:])
                    move_dict_value_up_one_level(values, name)
                    estimator = estimator.estimators[choice_index]
                    estimator_parameter = estimator_parameter['choices'][choice_index]

                parameter_values = values.get(name, {})
                self._flatten_values(parameter_values, estimator_parameter)

                cloned_estimator = clone(estimator)
                cloned_estimator.set_params(**parameter_values)

                estimators.append((name, cloned_estimator))

        return Pipeline(estimators)

    def _flatten_values(self, values: Dict, parameter_group: Dict) -> None:
        for parameter in parameter_group['items']:
            name = parameter['name']
            if name in values:
                value = values.get(name)
                if parameter['type'] == 'choice':
                    move_dict_value_up_one_level(values, name)
                elif parameter['type'] == 'group':
                    values[name] = list(value.values())
            else:
                values[name] = None
