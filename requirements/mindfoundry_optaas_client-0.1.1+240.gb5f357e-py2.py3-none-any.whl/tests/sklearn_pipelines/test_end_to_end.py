from random import randint

from sklearn import datasets

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.sklearn_pipelines.forest import RandomForestClassifier, \
    ExtraTreesClassifier, ExtraTreesRegressor, RandomForestRegressor
from mindfoundry.optaas.client.sklearn_pipelines.ica import FastICA
from mindfoundry.optaas.client.sklearn_pipelines.linear_svc import LinearSVC
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator, ParametersAndConstraints, \
    optional_step, OptionalStepMixin, choice, optional_choice
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker
from mindfoundry.optaas.client.sklearn_pipelines.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.voting import VotingClassifier
from mindfoundry.optaas.client.sklearn_pipelines.xgboost import XGBClassifier
from tests.sklearn_pipelines.utils import SklearnTest


class TestEndToEnd(SklearnTest):
    def test_PCA_and_SVC_or_XGBoost(self):
        task = self.optimize_pipeline([
            ('reduce_dim', optional_step(PCA())),
            ('clf', choice(
                LinearSVC(),
                XGBClassifier()
            ))
        ])

        with self.assertRaisesOPTaaSError(400, "Configuration violates constraint: if #clf__0__fit_intercept == true "
                                               "then #clf__0__intercept_scaling is_present"):
            task.add_user_defined_configuration({
                'clf': {
                    'clf__0': {
                        'C': 0.2,
                        'fit_intercept': True,
                        'multi_class': 'crammer_singer',
                        'tol': 0.3,
                    }
                },
            })

        with self.assertRaisesOPTaaSError(400, "Configuration violates constraint: if #clf__0__fit_intercept == false "
                                               "then #clf__0__intercept_scaling is_absent"):
            task.add_user_defined_configuration({
                'clf': {
                    'clf__0': {
                        'C': 0.2,
                        'fit_intercept': False,
                        'intercept_scaling': 0.5,
                        'multi_class': 'crammer_singer',
                        'tol': 0.3,
                    }
                },
            })

        with self.assertRaisesOPTaaSError(
                400,
                "Configuration violates constraint: if #reduce_dim__svd_solver == 'arpack' "
                "then ( #reduce_dim__n_components_int < 4 ) && #reduce_dim__tol is_present"):
            task.add_user_defined_configuration({
                'clf': {
                    'clf__0': {
                        'C': 0.2,
                        'fit_intercept': False,
                        'intercept_scaling': 0.5,
                        'multi_class': 'crammer_singer',
                        'tol': 0.3,
                    }
                },
                'reduce_dim': {
                    'svd_solver': 'arpack',
                    'iterated_power': {'iterated_power_auto': 'auto'},
                    'n_components': {'n_components_int': 3},
                    'whiten': True
                }
            })

        with self.assertRaisesOPTaaSError(
                400,
                "Configuration violates constraint: if #reduce_dim__svd_solver == 'arpack' "
                "then ( #reduce_dim__n_components_int < 4 ) && #reduce_dim__tol is_present"):
            task.add_user_defined_configuration({
                'clf': {
                    'clf__0': {
                        'C': 0.2,
                        'fit_intercept': False,
                        'intercept_scaling': 0.5,
                        'multi_class': 'crammer_singer',
                        'tol': 0.3,
                    }
                },
                'reduce_dim': {
                    'svd_solver': 'arpack',
                    'iterated_power': {'iterated_power_auto': 'auto'},
                    'n_components': {'n_components_int': 4},
                    'tol': 0.5,
                    'whiten': True
                }
            })

        self.verify_valid_configuration(task, {
            'clf': {
                'clf__0': {
                    'C': 0.2,
                    'fit_intercept': False,  # False and no intercept_scaling present
                    'multi_class': 'crammer_singer',
                    'tol': 0.3,
                }
            },
            # PCA not present
        })

        self.verify_valid_configuration(task, {
            'clf': {
                'clf__0': {
                    'C': 0.2,
                    'fit_intercept': True,  # True and intercept_scaling present
                    'intercept_scaling': 0.5,
                    'multi_class': 'crammer_singer',
                    'tol': 0.3,
                }
            },
            'reduce_dim': {  # PCA present
                'svd_solver': 'auto',
                'iterated_power': {'iterated_power_auto': 'auto'},
                'whiten': True
            }
        })

    def verify_valid_configuration(self, task, values):
        config = task.add_user_defined_configuration(values=values)
        self.assertEqual('user-defined', config.type)
        self.assertEqual(values, config.values)
        self.calculate_score(task, config)

    def test_ICA_and_forests(self):
        self.optimize_pipeline([
            ('reduce_dim', optional_choice(
                FastICA(),
                BasePCA()
            )),
            ('clf', choice(
                RandomForestClassifier(),
                ExtraTreesClassifier(),
                VotingClassifier([
                    ('rf', RandomForestClassifier()),
                    ('et', ExtraTreesClassifier())
                ])
            ))
        ])

    def test_user_defined(self):
        class UserDefinedEstimator(OptimizableBaseEstimator):
            test = self

            def __init__(self, int_param: int = 3, cat_param: str = None, float_param: float = 0.1,
                         non_optimizable_param=9):
                self.int_param = int_param
                self.cat_param = cat_param
                self.float_param = float_param
                self.non_optimizable_param = non_optimizable_param

            def make_parameters_and_constraints(self, sk: SklearnParameterMaker,
                                                **kwargs) -> ParametersAndConstraints:
                int_param = sk.IntParameter('int_param', minimum=1, maximum=10)
                float_param = sk.FloatParameter('float_param', minimum=0, maximum=1)
                cat_param = sk.CategoricalParameter('cat_param', values=['a', 'b', 'c', 'd'])
                constraints = [
                    Constraint(when=int_param == 2, then=cat_param != 'a'),
                    Constraint((float_param <= 0.2) | (float_param > 0.32))
                ]
                return [int_param, float_param, cat_param], constraints

            def fit(self, X, y=None, **fit_params):
                self.test.assertTrue(0 <= self.float_param <= 0.2 or 0.32 < self.float_param <= 1)
                self.test.assertIn(self.int_param, range(1, 11))
                if self.int_param == 2:
                    self.test.assertIn(self.cat_param, ['b', 'c', 'd'])
                else:
                    self.test.assertIn(self.cat_param, ['a', 'b', 'c', 'd'])
                self.test.assertIn(self.non_optimizable_param, [2, 3, 9])

                return self

            def predict(self, X):
                return [randint(0, 2) for _ in X]

            def transform(self, X):
                return X

        class OptionalUserDefinedEstimator(UserDefinedEstimator, OptionalStepMixin):
            pass

        self.optimize_pipeline([
            ('user_defined', UserDefinedEstimator(cat_param='c', non_optimizable_param=2)),
            ('optional', optional_step(UserDefinedEstimator(int_param=9, float_param=0.13))),
            ('optional_mixin', OptionalUserDefinedEstimator(cat_param='a', non_optimizable_param=3))
        ], ignore_score=True)


class TestEndToEndRegressors(SklearnTest):
    scoring = 'explained_variance'
    dataset = datasets.load_boston()
    expected_best_non_default_score = 0.3

    def test_regressors(self):
        self.optimize_pipeline([
            ('regressor', choice(
                RandomForestRegressor(),
                ExtraTreesRegressor()
            ))
        ])
