from sklearn.ensemble import AdaBoostClassifier as BaseAdaBoostClassifier, AdaBoostRegressor as BaseAdaBoostRegressor

from mindfoundry.optaas.client.parameter import Distribution
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator, ParametersAndConstraints
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker


class AdaBoostClassifier(BaseAdaBoostClassifier, OptimizableBaseEstimator):
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize an :class:`.AdaBoostClassifier`."""

        parameters = [
            sk.IntParameter('n_estimators', minimum=10, maximum=500),
            sk.FloatParameter('learning_rate', minimum=0.01, maximum=2.5, distribution=Distribution.LOGUNIFORM),
            sk.CategoricalParameter('algorithm', values=['SAMME', 'SAMME.R'])
        ]

        return parameters, []


class AdaBoostRegressor(BaseAdaBoostRegressor, OptimizableBaseEstimator):
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize an :class:`.AdaBoostRegressor`."""

        parameters = [
            sk.IntParameter('n_estimators', minimum=10, maximum=500),
            sk.FloatParameter('learning_rate', minimum=0.01, maximum=5.0),
            sk.CategoricalParameter('loss', values=['linear', 'square', 'exponential'])
        ]

        return parameters, []
