from typing import List, Union, TypeVar, Callable, Any, Dict

from sklearn.base import BaseEstimator

from mindfoundry.optaas.client.parameter import Parameter, ChoiceParameter, CategoricalParameter, GroupParameter, \
    ConstantParameter, BoolParameter, Distribution, IntParameter, FloatParameter, SubsetParameter

T = TypeVar('T', bound=Parameter)


class SklearnParameterMaker:
    """Creates :class:`Parameters <.Parameter>` with the correct names and default values for optimizing a sklearn :class:`.Pipeline`

    Convenience methods are provided for each :class:`.Parameter` subclass, so that you can call `sk.IntParameter(...)`
    instead of `IntParameter(...)`.
    """

    def __init__(self, estimator_name: str, estimator: BaseEstimator):
        self.prefix = estimator_name + '__'
        self._defaults: Dict[str, Any] = estimator.get_params()

    def GroupParameter(self, name: str, items: List[Parameter], optional: bool = None) -> GroupParameter:
        return self.make_parameter(GroupParameter, name=name, items=items, optional=optional)

    def ChoiceParameter(self, name: str, choices: List[Parameter], optional: bool = None) -> ChoiceParameter:
        return self.make_parameter(ChoiceParameter, name=name, choices=choices, optional=optional)

    def CategoricalParameter(self, name: str, values: List[Union[str, int, float, bool]],
                             optional: bool = None) -> CategoricalParameter:
        return self.make_parameter(CategoricalParameter, name=name, values=values, optional=optional)

    def SubsetParameter(self, name: str, values: List[Union[str, int, float, bool]],
                        optional: bool = None) -> SubsetParameter:
        return self.make_parameter(SubsetParameter, name=name, values=values, optional=optional)

    def ConstantParameter(self, name: str, value: Union[str, int, float, bool],
                          optional: bool = None) -> ConstantParameter:
        return self.make_parameter(ConstantParameter, name=name, value=value, optional=optional, )

    def BoolParameter(self, name: str, optional: bool = None) -> BoolParameter:
        return self.make_parameter(BoolParameter, name=name, optional=optional)

    def IntParameter(self, name: str, minimum: int, maximum: int, distribution: Distribution = None,
                     optional: bool = None) -> IntParameter:
        return self.make_parameter(IntParameter, name=name, minimum=minimum, maximum=maximum, optional=optional,
                                   distribution=distribution)

    def FloatParameter(self, name: str, minimum: float, maximum: float, distribution: Distribution = None,
                       optional: bool = None) -> FloatParameter:
        return self.make_parameter(FloatParameter, name=name, minimum=minimum, maximum=maximum, optional=optional,
                                   distribution=distribution)

    def IntOrAuto(self, name: str, minimum: int, maximum: int, distribution: Distribution = None,
                  optional: bool = None) -> ChoiceParameter:
        """Creates a choice between an IntParameter and the string 'auto'."""
        int_param = self.IntParameter(name=name + '_int', minimum=minimum, maximum=maximum, optional=optional,
                                      distribution=distribution)
        auto = self.ConstantParameter(name=name + '_auto', value='auto')
        return self.ChoiceParameter(name, choices=[int_param, auto])

    def FloatOrAuto(self, name: str, minimum: float, maximum: float, distribution: Distribution = None,
                    optional: bool = None) -> ChoiceParameter:
        """Creates a choice between a FloatParameter and the string 'auto'."""
        float_param = self.FloatParameter(name=name + '_float', minimum=minimum, maximum=maximum, optional=optional,
                                          distribution=distribution)
        auto = self.ConstantParameter(name=name + '_auto', value='auto')
        return self.ChoiceParameter(name, choices=[float_param, auto])

    def make_parameter(self, parameter_type: Callable[..., T], name: str, **kwargs) -> T:
        """Creates a parameter so as to facilitate the generation of a sklearn Pipeline from a :class:`.Configuration`.

        Args:
            parameter_type (Callable[..., T]): The specific Parameter subclass of the parameter you want to create, e.g. :class:`.IntParameter`.
            name (str): Parameter name, should match the name expected by the estimator's `set_params` method exactly.
            kwargs: Any additional arguments for the parameter constructor, e.g. `minimum`, `maximum`, `choices` etc.
                **Do not** include a value for the `id` and `default` arguments, because it will be overwritten.
                The `id` will be generated from the parameter name (any spaces will be replaced by underscores) and prefixed
                with the estimator name.
                The `default` will be taken from `estimator.get_params()`, i.e. it should be set in the estimator constructor.
        """
        kwargs['name'] = name
        kwargs['id'] = self.prefix + name.replace(' ', '_')

        default = self._defaults.get(name)

        if default is None:
            kwargs.pop('default', None)
            if kwargs.get('optional') is True:
                kwargs['include_in_default'] = False
        else:
            if parameter_type == ChoiceParameter:
                default_choice = self._get_default_choice(default, kwargs)
                if not isinstance(default_choice, ConstantParameter):
                    setattr(default_choice, 'default', default)
                if hasattr(default_choice, 'includeInDefault'):
                    delattr(default_choice, 'includeInDefault')
                default = default_choice
            elif parameter_type == GroupParameter:
                for i, value in enumerate(default):
                    item = kwargs['items'][i]
                    setattr(item, 'default', value)
                    if hasattr(item, 'includeInDefault'):
                        delattr(item, 'includeInDefault')

            kwargs.pop('include_in_default', None)

            if parameter_type != GroupParameter:
                kwargs['default'] = default

        return parameter_type(**kwargs)

    def _get_default_choice(self, default_value, kwargs) -> Parameter:
        for choice in kwargs['choices']:
            if choice.is_compatible_value(default_value):
                return choice
        raise ValueError(f"{default_value} is not a valid default value for parameter '{kwargs['name']}'")
