from mindfoundry.optaas.client.sklearn_pipelines.estimators.ica import FastICA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.svc import LinearSVC
from mindfoundry.optaas.client.sklearn_pipelines.estimators.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.mixin import optional_step, choice, optional_choice
from tests.sklearn_pipelines.utils import MockClientTest
from tests.utils import MockConfiguration

n_components = 13
base_n_components = 14
feature_count = 20

linear_svc_config = {
    'C': 0.2,
    'fit_intercept': False,
    'multi_class': 'crammer_singer',
    'tol': 0.3,
}

configuration_with_pca = MockConfiguration(values={
    'reduce_dim': {
        'reduce_dim__0': {
            'n_components': {'n_components_int': n_components},
            'whiten': True,
            'svd_solver': 'auto',
            'iterated_power': {'iterated_power_int': 3},
            'tol': 0.2
        }
    },
    'svc': linear_svc_config
})

configuration_with_base_pca = MockConfiguration(values={
    'reduce_dim': {
        'reduce_dim__1': {}
    },
    'svc': linear_svc_config
})

configuration_with_ica = MockConfiguration(values={
    'reduce_dim': {
        'reduce_dim__2': {
            'n_components': n_components,
            'whiten': True,
            'fun': 'cube',
            'algorithm': 'deflation',
            'tol': 0.2
        }
    },
    'svc': linear_svc_config
})

configuration_with_only_svc = MockConfiguration(values={'svc': linear_svc_config})

linear_svc_params = LinearSVC(C=0.2, fit_intercept=False, multi_class='crammer_singer', tol=0.3,
                              dual=None, intercept_scaling=None, penalty=None, loss=None).get_params()
pca_params = PCA(n_components=n_components, whiten=True, iterated_power=3, tol=0.2).get_params()
base_pca_params = PCA(n_components=base_n_components).get_params()
ica_params = FastICA(n_components=n_components, whiten=True, fun='cube', algorithm='deflation', tol=0.2).get_params()


class TestChoice(MockClientTest):
    def test_choice(self):
        task = self.create_mock_task([
            ('reduce_dim', choice(
                PCA(n_components=1),
                BasePCA(n_components=base_n_components),
                optional_step(FastICA(n_components=3))
            )),
            ('svc', LinearSVC())
        ], feature_count=feature_count)

        with self.subTest('with pca'):
            pipe_with_pca = task.make_pipeline(configuration_with_pca)
            self.assert_pipeline_with_pca(pipe_with_pca, PCA, pca_params)

        with self.subTest('with base pca'):
            pipe_with_base_pca = task.make_pipeline(configuration_with_base_pca)
            self.assert_pipeline_with_pca(pipe_with_base_pca, BasePCA, base_pca_params)

        with self.subTest('with ica'):
            pipe_with_ica = task.make_pipeline(configuration_with_ica)
            self.assert_pipeline_with_pca(pipe_with_ica, FastICA, ica_params)

        with self.subTest('with only svc'):
            pipe_with_only_svc = task.make_pipeline(configuration_with_only_svc)
            self.assert_pipeline_with_only_svc(pipe_with_only_svc)

    def test_optional_choice(self):
        task = self.create_mock_task([
            ('reduce_dim', optional_choice(
                PCA(n_components=1),
                BasePCA(n_components=base_n_components),
                FastICA(n_components=3)
            )),
            ('svc', LinearSVC())
        ], feature_count=feature_count)

        with self.subTest('with pca'):
            pipe_with_pca = task.make_pipeline(configuration_with_pca)
            self.assert_pipeline_with_pca(pipe_with_pca, PCA, pca_params)

        with self.subTest('with base pca'):
            pipe_with_base_pca = task.make_pipeline(configuration_with_base_pca)
            self.assert_pipeline_with_pca(pipe_with_base_pca, BasePCA, base_pca_params)

        with self.subTest('with ica'):
            pipe_with_ica = task.make_pipeline(configuration_with_ica)
            self.assert_pipeline_with_pca(pipe_with_ica, FastICA, ica_params)

        with self.subTest('only svc'):
            pipe_with_only_svc = task.make_pipeline(configuration_with_only_svc)
            self.assert_pipeline_with_only_svc(pipe_with_only_svc)

    def assert_pipeline_with_pca(self, pipe, expected_estimator_type, expected_pca_params):
        self.assertEqual(2, len(pipe.steps))

        pca = pipe.steps[0][1]
        self.assertIsInstance(pca, expected_estimator_type)
        self.assertEqual(expected_pca_params, pca.get_params())

        svc = pipe.steps[1][1]
        self.assertIsInstance(svc, LinearSVC)
        self.assertEqual(linear_svc_params, svc.get_params())

    def assert_pipeline_with_only_svc(self, pipe):
        self.assertEqual(1, len(pipe.steps))
        svc = pipe.steps[0][1]
        self.assertIsInstance(svc, LinearSVC)
        self.assertEqual(linear_svc_params, svc.get_params())
