from decorator import contextmanager

from mindfoundry.optaas.client.client import Goal
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ada_boost import AdaBoostClassifier, AdaBoostRegressor
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ensemble import RandomForestClassifier, \
    ExtraTreesClassifier, RandomForestRegressor, ExtraTreesRegressor, DecisionTreeClassifier, DecisionTreeRegressor, \
    GradientBoostingRegressor, GradientBoostingClassifier
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ica import FastICA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.k_neighbors import KNeighborsClassifier, KNeighborsRegressor
from mindfoundry.optaas.client.sklearn_pipelines.estimators.svc import LinearSVC, SVC
from mindfoundry.optaas.client.sklearn_pipelines.estimators.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.voting import VotingClassifier
from mindfoundry.optaas.client.sklearn_pipelines.estimators.xgboost import XGBClassifier
from mindfoundry.optaas.client.sklearn_pipelines.mixin import MissingArgumentError, optional_step, choice, \
    optional_choice
from tests.sklearn_pipelines.utils import SklearnTest, MockClientTest


class TestCreate(SklearnTest):
    def test_create_sklearn_task(self):
        estimators = [
            ('reduce_dim', optional_choice(
                PCA(whiten=True, n_components=2),
                FastICA(n_components=3),
            )),
            ('clf', LinearSVC(penalty='l1', dual=False, tol=0.3))
        ]
        user_defined_data = [{
            'my': 'data',
            'here': [1, 2, 3]
        }, 'a', 'b', 'c']
        task = self.client.create_sklearn_task(title='Sklearn Test', estimators=estimators, feature_count=9,
                                               random_seed=123, max_wait_time=4, initial_configurations=7,
                                               goal=Goal.max, user_defined_data=user_defined_data)

        task.refresh()
        self.assertEqual(0, task.number_of_iterations)
        self.assertEqual(user_defined_data, task.user_defined_data)
        self.assertEqual('running', task.status)


class TestResume(SklearnTest):
    def test_resume_sklearn_task(self):
        estimators = [
            ('reduce_dim', optional_step(BasePCA(whiten=True, n_components=2))),
            ('vt', VotingClassifier([
                ('rf', RandomForestClassifier()),
                ('et', ExtraTreesClassifier())
            ]))
        ]
        task = self.create_task(estimators)

        configuration = task.generate_configurations()[0]
        score = self.calculate_score(task, configuration)

        resumed_task = self.client.get_sklearn_task(task.id, estimators)
        next_configuration = resumed_task.record_result(configuration, score)
        next_score = self.calculate_score(resumed_task, next_configuration)
        resumed_task.record_result(next_configuration, next_score)

        resumed_task.refresh()
        self.assertEqual(2, resumed_task.number_of_iterations)
        self.assertEqual('running', resumed_task.status)


class TestDefaults(MockClientTest):
    def test_no_defaults_specified(self):
        with self.use_estimators(PCA(), LinearSVC()):
            self.assert_n_components_default(None)
            self.assert_tol_default(0.0001)

    @contextmanager
    def use_estimators(self, pca, svc=None):
        estimators = [('rd', pca)]
        if svc:
            estimators.append(('svc', svc))
        self.task = self.create_mock_task(estimators, feature_count=100, unrelated_arg='abc')
        yield

    def assert_n_components_default(self, expected_default, expected_type=None):
        with self.subTest('n_components'):
            n_components_choice = self.find_parameter('rd', 'n_components')
            if expected_default is None:
                self.assertFalse(n_components_choice['includeInDefault'])
            else:
                self.assertTrue(n_components_choice['default'].startswith('#'))
                n_components_default_id = n_components_choice['default'][1:]
                n_components = next(p for p in n_components_choice['choices'] if p['id'] == n_components_default_id)

                self.assertEqual(expected_type, n_components['type'])
                if expected_type == 'constant':
                    self.assertEqual(expected_default, n_components['value'])
                    self.assertNotIn('default', n_components)
                else:
                    self.assertEqual(expected_default, n_components['default'])

    def assert_tol_default(self, expected_default):
        with self.subTest('tol'):
            tol = self.find_parameter('svc', 'tol')
            self.assertEqual(expected_default, tol['default'])

    def test_n_components_int_and_tol(self):
        with self.use_estimators(PCA(n_components=7), LinearSVC(tol=0.123)):
            self.assert_n_components_default(7, 'integer')
            self.assert_tol_default(0.123)

    def test_n_components_mle(self):
        with self.use_estimators(PCA(n_components='mle')):
            self.assert_n_components_default('mle', 'constant')

    def test_n_components_float(self):
        with self.use_estimators(PCA(n_components=0.123)):
            self.assert_n_components_default(0.123, 'number')

    def test_n_components_invalid(self):
        with self.assertRaisesRegex(ValueError,
                                    "invalid_string is not a valid default value for parameter 'n_components'"):
            self.create_mock_task([('pca', PCA(n_components='invalid_string'))], feature_count=9)

    def test_optional_pca(self):
        with self.use_estimators(optional_step(PCA())):
            self.assert_n_components_default(None)

    def test_optional_pca_with_int(self):
        with self.use_estimators(optional_step(PCA(n_components=2))):
            self.assert_n_components_default(2, 'integer')

    def test_choice(self):
        with self.use_estimators(
                choice(
                    PCA(n_components=1),
                    BasePCA(n_components=2),
                    optional_step(FastICA(n_components=3))
                ),
                LinearSVC(tol=0.123)
        ):
            self.assertEqual(2, len(self.task.parameters))
            self.assert_tol_default(0.123)

            choice_parameter = next(p for p in self.task.parameters if p['name'] == 'rd')
            self.assertEqual('choice', choice_parameter['type'])

            choices = choice_parameter['choices']
            self.assertEqual(3, len(choices))

            with self.subTest('PCA'):
                pca = choices[0]
                n_components_choice = next(p for p in pca['items'] if p['name'] == 'n_components')
                n_components_default_id = n_components_choice['default'][1:]
                n_components = next(p for p in n_components_choice['choices'] if p['id'] == n_components_default_id)
                self.assertEqual(1, n_components['default'])

            with self.subTest('BasePCA'):
                self.assertEqual([], choices[1]['items'])

            with self.subTest('ICA'):
                ica = choices[2]
                self.assertTrue(ica['optional'])
                n_components = next(p for p in ica['items'] if p['name'] == 'n_components')
                self.assertEqual(3, n_components['default'])

    def test_optional_choice(self):
        with self.use_estimators(
                optional_choice(
                    PCA(n_components=1),
                    FastICA(n_components=2)
                ),
                LinearSVC(tol=0.123)
        ):
            self.assertEqual(2, len(self.task.parameters))
            self.assert_tol_default(0.123)

            choice_parameter = next(p for p in self.task.parameters if p['name'] == 'rd')
            self.assertEqual('choice', choice_parameter['type'])
            self.assertTrue(choice_parameter['optional'])

            choices = choice_parameter['choices']
            self.assertEqual(2, len(choices))

            with self.subTest('PCA'):
                pca = choices[0]
                n_components_choice = next(p for p in pca['items'] if p['name'] == 'n_components')
                n_components_default_id = n_components_choice['default'][1:]
                n_components = next(p for p in n_components_choice['choices'] if p['id'] == n_components_default_id)
                self.assertEqual(1, n_components['default'])

            with self.subTest('ICA'):
                ica = choices[1]
                n_components = next(p for p in ica['items'] if p['name'] == 'n_components')
                self.assertEqual(2, n_components['default'])


class TestValidation(MockClientTest):
    def test_PCA_without_feature_count(self):
        estimators = [('reduce_dim', PCA())]
        with self.assertRaisesRegex(MissingArgumentError,
                                    "feature_count is required in kwargs in order to optimize PCA"):
            self.create_mock_task(estimators)

    def test_space_in_estimator_name_is_converted_to_underscore_for_id(self):
        estimators = [('random forest', RandomForestClassifier())]
        task = self.create_mock_task(estimators)
        wrong_ids = [p for p in task.parameters if ' ' in p['id']]
        self.assertEqual(0, len(wrong_ids), f"These ids contain a space: {wrong_ids}")


class TestParameters(MockClientTest):
    excluded_forest_parameters = ['random_state', 'verbose', 'warm_start', 'n_jobs', 'class_weight',
                                  'min_impurity_split']
    excluded_parameters = {
        'ada_boost': ['random_state', 'base_estimator'],
        'ada_boost_reg': ['random_state', 'base_estimator'],
        'grad_boost': ['random_state', 'min_impurity_split', 'init', 'verbose', 'warm_start'],
        'grad_boost_reg': ['random_state', 'min_impurity_split', 'init', 'warm_start', 'verbose'],
        'pca': ['copy', 'random_state'],
        'opt_pca': ['copy', 'random_state'],
        'ica': ['copy', 'random_state', 'fun_args', 'max_iter', 'w_init'],
        'svc': ['random_state', 'max_iter', 'verbose', 'probability', 'cache_size', 'decision_function_shape'],
        'linear_svc': ['random_state', 'max_iter', 'verbose'],
        'my_svc': ['random_state', 'max_iter', 'verbose'],
        'rf': excluded_forest_parameters,
        'rf_reg': excluded_forest_parameters,
        'extr': excluded_forest_parameters,
        'extr_reg': excluded_forest_parameters,
        'voting': ['vet__' + p for p in excluded_forest_parameters] +
                  ['vrf__' + p for p in excluded_forest_parameters] +
                  ['vet', 'vrf', 'estimators', 'flatten_transform', 'n_jobs'],
        'dtc': ['random_state', 'min_impurity_split', 'class_weight'],
        'dtr': ['random_state', 'min_impurity_split'],
        'kn': ['metric', 'n_jobs', 'metric_params', 'leaf_size'],
        'kn_reg': ['metric', 'n_jobs', 'metric_params', 'leaf_size'],
        'xg': ['silent', 'nthread', 'missing', 'seed', 'random_state', 'n_jobs'],
    }

    def test_all_required_parameters_are_generated_with_correct_names(self):
        estimators = [
            ('pca', PCA()),
            ('opt_pca', optional_step(PCA())),
            ('ica', FastICA()),
            ('svc', SVC()),
            ('linear_svc', LinearSVC()),
            ('rf', RandomForestClassifier()),
            ('rf_reg', RandomForestRegressor()),
            ('extr', ExtraTreesClassifier()),
            ('extr_reg', ExtraTreesRegressor()),
            ('voting', VotingClassifier([
                ('vrf', RandomForestClassifier()),
                ('vet', ExtraTreesClassifier())
            ])),
            ('ada_boost', AdaBoostClassifier()),
            ('ada_boost_reg', AdaBoostRegressor()),
            ('grad_boost', GradientBoostingClassifier()),
            ('grad_boost_reg', GradientBoostingRegressor()),
            ('dtc', DecisionTreeClassifier()),
            ('dtr', DecisionTreeRegressor()),
            ('kn', KNeighborsClassifier()),
            ('kn_reg', KNeighborsRegressor()),
            ('xg', XGBClassifier()),
        ]
        self.task = self.create_mock_task(estimators, feature_count=5, class_count=2)

        for estimator_name, estimator in estimators:
            with self.subTest(estimator_name):
                self.verify_parameters(estimator_name, estimator)

    def verify_parameters(self, estimator_name, estimator):
        root_parameter = next(p for p in self.task.parameters if p['name'] == estimator_name)
        required_parameter_names = {p for p in estimator.get_params()
                                    if p not in self.excluded_parameters[estimator_name]}
        generated_parameter_names = {parameter['name'] for parameter in root_parameter['items']}

        missing_parameter_names = required_parameter_names - generated_parameter_names
        excess_parameter_names = generated_parameter_names - required_parameter_names
        if missing_parameter_names or excess_parameter_names:
            self.fail(f'Missing parameters: {missing_parameter_names}   Excess parameters: {excess_parameter_names}')

    def test_estimator_that_extends_predefined_class(self):
        class MyLinearSVC(LinearSVC):
            pass

        estimators = [('my_svc', MyLinearSVC())]
        self.task = self.create_mock_task(estimators)
        self.verify_parameters('my_svc', LinearSVC())

    def test_feature_count_is_used_in_PCA(self):
        feature_count = 999
        estimators = [('pca', PCA())]
        self.task = self.create_mock_task(estimators, feature_count=feature_count)
        n_components_choice = self.find_parameter('pca', 'n_components')
        n_components_int = next(p for p in n_components_choice['choices'] if p['name'] == 'n_components_int')
        self.assertEqual(feature_count, n_components_int['maximum'])

    def test_voting_weights(self):
        self.assert_correct_voting_weights('forest only', [
            ('rf', RandomForestClassifier()),
        ])
        self.assert_correct_voting_weights('trees only', [
            ('extr', ExtraTreesClassifier())
        ])
        self.assert_correct_voting_weights('both', [
            ('forest', RandomForestClassifier()),
            ('trees', ExtraTreesClassifier())
        ])

    def assert_correct_voting_weights(self, description, voting_estimators):
        with self.subTest(description):
            estimators = [('voting', VotingClassifier(voting_estimators))]
            self.task = self.create_mock_task(estimators)
            weights = self.find_parameter('voting', 'weights')
            self.assertEqual(len(voting_estimators), len(weights['items']))

    def test_optional(self):
        feature_count = 9
        task_with_pca = self.create_mock_task([('reduce_dim', PCA())], feature_count=feature_count)
        task_with_optional_pca = self.create_mock_task([('reduce_dim', optional_step(PCA()))],
                                                       feature_count=feature_count)

        expected_parameter = {
            'name': 'reduce_dim',
            'id': 'reduce_dim',
            'type': 'group',
            'optional': True,
            'items': task_with_pca.parameters[0]['items']
        }
        self.assertEqual([expected_parameter], task_with_optional_pca.parameters)
        self.assertEqual(task_with_pca.constraints, task_with_optional_pca.constraints)

    def test_optional_non_optimizable(self):
        task = self.create_mock_task([('reduce_dim', optional_step(BasePCA()))])

        expected_parameter = {
            'name': 'reduce_dim',
            'id': 'reduce_dim',
            'type': 'group',
            'optional': True,
            'items': []
        }
        self.assertEqual([expected_parameter], task.parameters)
        self.assertEqual([], task.constraints)

    def test_choice(self):
        self.assert_choice_parameters_and_constraints(optional=False)

    def assert_choice_parameters_and_constraints(self, optional: bool):
        if optional:
            estimator = optional_choice(PCA(), FastICA(), BasePCA())
        else:
            estimator = choice(PCA(), FastICA(), BasePCA())

        feature_count = 9
        task_with_choice = self.create_mock_task([('rd', estimator)], feature_count=feature_count)
        task_with_pca = self.create_mock_task([('rd__0', PCA())], feature_count=feature_count)
        task_with_ica = self.create_mock_task([('rd__1', FastICA())], feature_count=feature_count)
        task_with_base_pca = self.create_mock_task([('rd__2', BasePCA())])

        expected_parameter = {
            'name': 'rd',
            'id': 'rd',
            'type': 'choice',
            'choices': [task_with_pca.parameters[0], task_with_ica.parameters[0], task_with_base_pca.parameters[0]]
        }
        if optional:
            expected_parameter['optional'] = True

        self.assertEqual([expected_parameter], task_with_choice.parameters)
        self.assertEqual(task_with_pca.constraints + task_with_ica.constraints, task_with_choice.constraints)

    def test_optional_choice(self):
        self.assert_choice_parameters_and_constraints(optional=True)
