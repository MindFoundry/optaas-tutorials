from decorator import contextmanager

from mindfoundry.optaas.client.sklearn_pipelines.estimators.ada_boost import AdaBoostClassifier
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ensemble import RandomForestClassifier
from mindfoundry.optaas.client.sklearn_pipelines.estimators.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.voting import VotingClassifier
from mindfoundry.optaas.client.sklearn_pipelines.mixin import optional_step
from tests.sklearn_pipelines.utils import MockClientTest
from tests.utils import MockConfiguration

max_leaf_nodes_default = None
max_leaf_nodes_assigned = 99
max_leaf_nodes_another = 77

max_features_default = 'auto'
max_features_assigned = 0.33
max_features_another = 'sqrt'

n_estimators_default = 10
n_estimators_assigned = 12
n_estimators_another = 27

configurations = {
    'only estimators': {'clf': {'n_estimators': n_estimators_assigned}},
    'features missing': {'clf': {'max_leaf_nodes': max_leaf_nodes_assigned, 'n_estimators': n_estimators_assigned}},
    'leaf missing': {'clf': {
        'max_features': {'max_features_float': max_features_assigned},
        'n_estimators': n_estimators_assigned
    }},
    'all assigned': {'clf': {
        'max_leaf_nodes': max_leaf_nodes_assigned,
        'max_features': {'max_features_float': max_features_assigned},
        'n_estimators': n_estimators_assigned
    }},
    'another all assigned': {'clf': {
        'max_leaf_nodes': max_leaf_nodes_another,
        'max_features': {'max_features_string': max_features_another},
        'n_estimators': n_estimators_another
    }},
}


class TestMakePipeline(MockClientTest):
    maxDiff = None

    def test_correct_values_assigned(self):
        default = RandomForestClassifier()
        self.assertEqual(max_leaf_nodes_default, default.max_leaf_nodes)
        self.assertEqual(max_features_default, default.max_features)
        self.assertEqual(n_estimators_default, default.n_estimators)

        self.task = self.create_random_forest_task()

        with self.use_configuration('all assigned'):
            self.assert_values(max_leaf_nodes_assigned, max_features_assigned, n_estimators_assigned)

    def create_random_forest_task(self, **kwargs):
        estimators = [('clf', RandomForestClassifier(**kwargs))]
        return self.create_mock_task(estimators)

    @contextmanager
    def use_configuration(self, configuration_key: str):
        with self.subTest(configuration_key):
            configuration = MockConfiguration(values=configurations[configuration_key])
            pipeline = self.task.make_pipeline(configuration)
            self.estimator = pipeline.steps[0][1]
            yield

    def assert_values(self, max_leaf_nodes, max_features, n_estimators):
        self.assertEqual(max_leaf_nodes, self.estimator.max_leaf_nodes)
        self.assertEqual(max_features, self.estimator.max_features)
        self.assertEqual(n_estimators, self.estimator.n_estimators)

    def test_initial_values_are_overwritten_when_assigned(self):
        self.task = self.create_random_forest_task(max_features='sqrt', n_estimators=22, max_leaf_nodes=85)

        with self.use_configuration('all assigned'):
            self.assert_values(max_leaf_nodes_assigned, max_features_assigned, n_estimators_assigned)

    def test_values_from_previous_configurations_are_NOT_preserved(self):
        self.task = self.create_random_forest_task(max_features='sqrt', n_estimators=22, max_leaf_nodes=85)

        with self.use_configuration('all assigned'):
            self.assert_values(max_leaf_nodes_assigned, max_features_assigned, n_estimators_assigned)

        with self.use_configuration('another all assigned'):
            self.assert_values(max_leaf_nodes_another, max_features_another, n_estimators_another)

        with self.use_configuration('leaf missing'):
            self.assert_values(None, max_features_assigned, n_estimators_assigned)

        with self.use_configuration('features missing'):
            self.assert_values(max_leaf_nodes_assigned, None, n_estimators_assigned)

    def test_if_missing_from_configuration_then_should_set_to_None(self):
        self.task = self.create_random_forest_task(max_features='sqrt', n_estimators=22, max_leaf_nodes=85)

        with self.use_configuration('leaf missing'):
            self.assert_values(None, max_features_assigned, n_estimators_assigned)

        with self.use_configuration('features missing'):
            self.assert_values(max_leaf_nodes_assigned, None, n_estimators_assigned)

        with self.use_configuration('only estimators'):
            self.assert_values(None, None, n_estimators_assigned)

    def test_voting_parameters(self):
        expected_weights = [0.56, 0.14, 0.75, 0.23, 0.99, 0.88]

        configuration = MockConfiguration(values={
            'voting': {
                'weights': {
                    'weight_0': expected_weights[0],
                    'weight_1': expected_weights[1],
                    'weight_2': expected_weights[2],
                    'weight_3': expected_weights[3],
                    'weight_4': expected_weights[4],
                    'weight_5': expected_weights[5],
                },
                'rf0__n_estimators': n_estimators_assigned,
                'rf3__n_estimators': n_estimators_another,
            }
        })

        task = self.create_mock_task([('voting', VotingClassifier([
            ('rf0', RandomForestClassifier()),
            ('rf1', RandomForestClassifier()),
            ('rf2', RandomForestClassifier()),
            ('rf3', RandomForestClassifier()),
            ('rf4', RandomForestClassifier()),
            ('rf5', RandomForestClassifier()),
        ]))])

        pipe = task.make_pipeline(configuration)

        self.assertEqual(expected_weights, pipe.get_params()['voting__weights'])
        self.assertEqual(n_estimators_assigned, pipe.get_params()['voting__rf0__n_estimators'])
        self.assertEqual(n_estimators_another, pipe.get_params()['voting__rf3__n_estimators'])
