import copy
import warnings

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ensemble import RandomForestClassifier, \
    BaseRandomForestClassifier
from mindfoundry.optaas.client.sklearn_pipelines.estimators.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.voting import VotingClassifier
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator, ParametersAndConstraints, \
    OptionalStepMixin
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker
from tests.sklearn_pipelines.utils import MockClientTest
from tests.utils import MockConfiguration


def make_test_parameters_and_constraints(sk: SklearnParameterMaker, exclude_value) -> ParametersAndConstraints:
    criterion = sk.CategoricalParameter('criterion', values=['gini', 'entropy'])
    min_samples_split = sk.IntParameter('min_samples_split', minimum=2, maximum=20)
    min_samples_leaf = sk.IntParameter('min_samples_leaf', minimum=1, maximum=20)

    constraint1 = Constraint(when=criterion == 'gini', then=min_samples_split > 5)
    constraint2 = Constraint(min_samples_leaf != exclude_value)
    return [criterion, min_samples_split, min_samples_leaf], [constraint1, constraint2]


expected_parameters = [{
    'name': 'reduce_dim',
    'id': 'reduce_dim',
    'type': 'group',
    'items': []
}, {
    'name': 'user_defined',
    'id': 'user_defined',
    'type': 'group',
    'items': [
        {'name': 'criterion', 'id': 'user_defined__criterion', 'type': 'categorical',
         'enum': ['gini', 'entropy'], 'default': 'entropy'},
        {'name': 'min_samples_split', 'id': 'user_defined__min_samples_split', 'type': 'integer',
         'minimum': 2, 'maximum': 20, 'default': 3},
        {'name': 'min_samples_leaf', 'id': 'user_defined__min_samples_leaf', 'type': 'integer',
         'minimum': 1, 'maximum': 20, 'default': 1},
    ]
}]

expected_constraints = [
    "if #user_defined__criterion == 'gini' then #user_defined__min_samples_split > 5",
    "#user_defined__min_samples_leaf != 17"
]

configuration = MockConfiguration(values={
    'reduce_dim': {},
    'user_defined': {
        'criterion': 'gini',
        'min_samples_split': 7,
        'min_samples_leaf': 18
    }
})

expected_pca_warning = "Estimator ('reduce_dim', PCA) is not optimizable (not instance of OptimizableBaseEstimator)."

expected_pca_params = BasePCA().get_params()

base_estimator_with_configuration = BaseRandomForestClassifier(criterion='gini', min_samples_split=7,
                                                               min_samples_leaf=18)
expected_user_defined_params = base_estimator_with_configuration.get_params()


class TestUserDefined(MockClientTest):
    def test_non_optimizable_estimators_should_be_skipped(self):
        estimators = [
            ('reduce_dim_optimizable', PCA()),
            ('reduce_dim', BasePCA()),  # The base (i.e. native sklearn) classes are not optimizable
            ('voting', VotingClassifier([
                ('rf', RandomForestClassifier()),
                ('base_rd', BaseRandomForestClassifier())  # The base (i.e. native sklearn) classes are not optimizable
            ]))
        ]

        expected_warnings = [
            expected_pca_warning,
            "Estimator ('voting__base_rd', RandomForestClassifier) is not optimizable (not instance of OptimizableBaseEstimator)."
        ]

        with warnings.catch_warnings(record=True) as caught_warnings:
            self.create_mock_task(estimators, feature_count=5)

        self.assertEqual(expected_warnings, [str(w.message) for w in caught_warnings])

    def test_user_defined_subclass_should_be_optimized(self):
        class MyEstimator(OptimizableBaseEstimator):
            def __init__(self, criterion, min_samples_split=5, min_samples_leaf=1):
                self.criterion = criterion
                self.min_samples_split = min_samples_split
                self.min_samples_leaf = min_samples_leaf

            def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
                return make_test_parameters_and_constraints(sk, self._get_required_kwarg(kwargs, 'exclude_value'))

            def fit(self):
                pass

        self.verify_user_defined_estimator(MyEstimator, expected_estimator_params={
            'criterion': 'gini',
            'min_samples_split': 7,
            'min_samples_leaf': 18
        })

    def verify_user_defined_estimator(self, estimator_type,
                                      expected_estimator_params=expected_user_defined_params,
                                      expected_parameters=expected_parameters,
                                      expected_constraints=expected_constraints):
        estimator = estimator_type(criterion="entropy", min_samples_split=3)
        estimators = [('reduce_dim', BasePCA()), ('user_defined', estimator)]

        with warnings.catch_warnings(record=True) as caught_warnings:
            task = self.create_mock_task(estimators, exclude_value=17)

        self.assertEqual(1, len(caught_warnings))
        self.assertEqual(expected_pca_warning, str(caught_warnings[0].message))

        self.assertEqual(expected_parameters, task.parameters)
        self.assertEqual(expected_constraints, task.constraints)

        pipe = task.make_pipeline(configuration)
        self.assertEqual(expected_pca_params, pipe.get_params()['reduce_dim'].get_params())
        self.assertEqual(expected_estimator_params, pipe.get_params()['user_defined'].get_params())

        return task

    def test_user_defined_mixin_should_be_optimized(self):
        class MyMixinEstimator(BaseRandomForestClassifier, OptimizableBaseEstimator):
            def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
                return make_test_parameters_and_constraints(sk, self._get_required_kwarg(kwargs, 'exclude_value'))

        self.verify_user_defined_estimator(MyMixinEstimator)

    def test_user_defined_extension_of_predefined_class_should_be_optimized(self):
        class MyExtendedEstimator(RandomForestClassifier):
            def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
                return make_test_parameters_and_constraints(sk, self._get_required_kwarg(kwargs, 'exclude_value'))

        self.verify_user_defined_estimator(MyExtendedEstimator)

    def test_user_defined_optional_mixin_should_be_optimized(self):
        class MyMixinOptional(BaseRandomForestClassifier, OptionalStepMixin):
            def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
                return make_test_parameters_and_constraints(sk, self._get_required_kwarg(kwargs, 'exclude_value'))

        expected_with_optional = copy.deepcopy(expected_parameters)
        expected_with_optional[1]['optional'] = True

        task = self.verify_user_defined_estimator(MyMixinOptional, expected_parameters=expected_with_optional)

        pipe = task.make_pipeline(MockConfiguration(values={'reduce_dim': {}}))
        self.assertEqual(expected_pca_params, pipe.get_params()['reduce_dim'].get_params())
        self.assertNotIn('user_defined', pipe.get_params())

    def test_user_defined_optional_without_parameters(self):
        class MyMixinOptionalWithoutParameters(BaseRandomForestClassifier, OptionalStepMixin):
            pass

        expected_with_optional = copy.deepcopy(expected_parameters)
        expected_with_optional[1]['optional'] = True
        expected_with_optional[1]['items'] = []

        task = self.verify_user_defined_estimator(MyMixinOptionalWithoutParameters,
                                                  expected_parameters=expected_with_optional,
                                                  expected_constraints=[])

        pipe = task.make_pipeline(MockConfiguration(values={'reduce_dim': {}}))
        self.assertEqual(expected_pca_params, pipe.get_params()['reduce_dim'].get_params())
        self.assertNotIn('user_defined', pipe.get_params())
