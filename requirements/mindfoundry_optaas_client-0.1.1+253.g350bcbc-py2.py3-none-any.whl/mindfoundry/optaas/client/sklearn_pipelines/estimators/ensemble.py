import numpy as np
from sklearn.ensemble import \
    RandomForestClassifier as BaseRandomForestClassifier, \
    ExtraTreesClassifier as BaseExtraTreesClassifier, \
    RandomForestRegressor as BaseRandomForestRegressor, \
    ExtraTreesRegressor as BaseExtraTreesRegressor, \
    GradientBoostingClassifier as BaseGradientBoostingClassifier, \
    GradientBoostingRegressor as BaseGradientBoostingRegressor
from sklearn.tree import DecisionTreeClassifier as BaseDecisionTreeClassifier, \
    DecisionTreeRegressor as BaseDecisionTreeRegressor

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import Distribution
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker
from mindfoundry.optaas.client.sklearn_pipelines.utils import ParametersAndConstraints


class OptimizableEnsemble(OptimizableBaseEstimator):
    """Superclass for optimizable ensemble estimators."""

    # Properties must be specified in subclasses
    criterion_values = None
    min_samples_split_distribution = None
    max_depth_distribution = None
    min_impurity_decrease_maximum = None

    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize ensemble estimators."""

        max_features_float = sk.FloatParameter('max_features_float', minimum=0.0, maximum=1.0)
        max_features_string = sk.CategoricalParameter('max_features_string',
                                                      values=['auto', 'sqrt', 'log2'])
        max_features = sk.ChoiceParameter('max_features',
                                          choices=[max_features_float, max_features_string])

        min_samples_split_int = sk.IntParameter('min_samples_split_int', minimum=2, maximum=20,
                                                distribution=self.min_samples_split_distribution)
        min_samples_split_float = sk.FloatParameter('min_samples_split_float', minimum=0.0, maximum=1.0)
        min_samples_split = sk.ChoiceParameter('min_samples_split',
                                               choices=[min_samples_split_int, min_samples_split_float])

        min_samples_leaf_int = sk.IntParameter('min_samples_leaf_int', minimum=1, maximum=20)
        min_samples_leaf_float = sk.FloatParameter('min_samples_leaf_float', minimum=np.nextafter(0.0, 1), maximum=0.5)
        min_samples_leaf = sk.ChoiceParameter('min_samples_leaf',
                                              choices=[min_samples_leaf_int, min_samples_leaf_float])

        parameters = [
            max_features, min_samples_split, min_samples_leaf,
            sk.CategoricalParameter('criterion', values=self.criterion_values),
            sk.IntParameter('max_leaf_nodes', minimum=10, maximum=10000, optional=True,
                            distribution=Distribution.LOGUNIFORM),
            sk.IntParameter('max_depth', minimum=1, maximum=100, optional=True,
                            distribution=self.max_depth_distribution),
            sk.FloatParameter('min_weight_fraction_leaf', minimum=0.0, maximum=0.5),
            sk.FloatParameter('min_impurity_decrease', minimum=0, maximum=self.min_impurity_decrease_maximum),
        ]
        return parameters, []


class OptimizableForestOrTree(OptimizableEnsemble):
    """Superclass for optimizable forest/tree-based estimators."""

    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize forest/tree-based estimators."""

        parameters, constraints = super().make_parameters_and_constraints(sk, **kwargs)

        bootstrap = sk.BoolParameter('bootstrap')
        oob_score = sk.BoolParameter('oob_score')

        parameters.extend([
            bootstrap, oob_score,
            sk.IntParameter('n_estimators', minimum=10, maximum=500, distribution=Distribution.LOGUNIFORM),
        ])

        constraints.append(Constraint(when=bootstrap == False, then=oob_score != True))

        return parameters, constraints


class OptimizableEnsembleClassifier(OptimizableEnsemble):
    """Superclass for optimizable ensemble classifiers."""

    criterion_values = ['gini', 'entropy']
    min_impurity_decrease_maximum = 1


class OptimizableEnsembleRegressor(OptimizableEnsemble):
    """Superclass for optimizable ensemble regressors."""

    criterion_values = ['mse', 'mae']
    min_impurity_decrease_maximum = 0.01


class OptimizableRandomForest(OptimizableForestOrTree):
    """Superclass for optimizable RandomForest estimators."""

    min_samples_split_distribution = Distribution.UNIFORM
    max_depth_distribution = Distribution.LOGUNIFORM


class OptimizableExtraTrees(OptimizableForestOrTree):
    """Superclass for optimizable ExtraTrees estimators."""

    min_samples_split_distribution = Distribution.LOGUNIFORM
    max_depth_distribution = Distribution.UNIFORM


class RandomForestClassifier(BaseRandomForestClassifier, OptimizableEnsembleClassifier, OptimizableRandomForest):
    """Allows us to optimize :class:`.RandomForestClassifier` estimators."""
    pass


class ExtraTreesClassifier(BaseExtraTreesClassifier, OptimizableEnsembleClassifier, OptimizableExtraTrees):
    """Allows us to optimize :class:`.ExtraTreesClassifier` estimators."""
    pass


class RandomForestRegressor(BaseRandomForestRegressor, OptimizableEnsembleRegressor, OptimizableRandomForest):
    """Allows us to optimize :class:`.RandomForestRegressor` estimators."""
    pass


class ExtraTreesRegressor(BaseExtraTreesRegressor, OptimizableEnsembleRegressor, OptimizableExtraTrees):
    """Allows us to optimize :class:`.ExtraTreesRegressor` estimators."""
    pass


class OptimizableDecisionTree(OptimizableEnsemble):
    """Superclass for optimizable DecisionTree estimators."""

    min_samples_split_distribution = Distribution.LOGUNIFORM
    max_depth_distribution = Distribution.UNIFORM

    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize DecisionTree-based estimators."""

        parameters, constraints = super().make_parameters_and_constraints(sk, **kwargs)

        parameters.extend([
            sk.CategoricalParameter('splitter', values=["best", "random"]),
            sk.BoolParameter('presort'),
        ])

        return parameters, constraints


class DecisionTreeClassifier(BaseDecisionTreeClassifier, OptimizableDecisionTree, OptimizableEnsembleClassifier):
    """Allows us to optimize a :class:`.DecisionTreeClassifier`."""
    pass


class DecisionTreeRegressor(BaseDecisionTreeRegressor, OptimizableDecisionTree):
    """Allows us to optimize a :class:`.DecisionTreeRegressor`."""

    criterion_values = ["mse", "friedman_mse", "mae"]
    min_impurity_decrease_maximum = 0.01


class OptimizableGradientBoosting(OptimizableEnsemble):
    """Superclass for optimizable GradientBoosting estimators."""

    criterion_values = ["mse", "friedman_mse", "mae"]
    min_impurity_decrease_maximum = 1
    min_samples_split_distribution = Distribution.UNIFORM
    max_depth_distribution = Distribution.UNIFORM

    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize a GradientBoosting estimator."""

        parameters, constraints = super().make_parameters_and_constraints(sk, **kwargs)

        parameters.extend([
            sk.FloatParameter('learning_rate', minimum=0, maximum=1),
            sk.IntParameter('n_estimators', minimum=10, maximum=500),
            sk.FloatParameter('subsample', minimum=0, maximum=1),
            sk.CategoricalParameter('presort', values=[True, False, 'auto']),
        ])

        return parameters, constraints


class GradientBoostingClassifier(BaseGradientBoostingClassifier, OptimizableGradientBoosting):
    """Allows us to optimize a :class:`.GradientBoostingClassifier`."""

    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize a :class:`.GradientBoostingClassifier`.

        Args:
            class_count (int, optional): Number of classes in the classification dataset.
                If set to a number other than `2`, the `loss` parameter will not be optimized (because it can only be set to "deviance").
        """

        parameters, constraints = super().make_parameters_and_constraints(sk, **kwargs)

        if kwargs.get('class_count') == 2:
            parameters.append(sk.CategoricalParameter('loss', values=["deviance", "exponential"]))

        return parameters, constraints


class GradientBoostingRegressor(BaseGradientBoostingRegressor, OptimizableGradientBoosting):
    """Allows us to optimize a :class:`.GradientBoostingRegressor`."""


    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize a :class:`.GradientBoostingClassifier`."""

        parameters, constraints = super().make_parameters_and_constraints(sk, **kwargs)

        parameters.extend([
            sk.CategoricalParameter('loss', values=["ls", "lad", "huber", "quantile"]),
            sk.FloatParameter('alpha', minimum=0, maximum=1),
        ])

        return parameters, constraints
