from sklearn.svm import SVC as BaseSVC, LinearSVC as BaseLinearSVC

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import Distribution
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker
from mindfoundry.optaas.client.sklearn_pipelines.utils import ParametersAndConstraints


class OptimizableSVC(OptimizableBaseEstimator):
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize an SVC-based estimator."""

        parameters = [
            sk.FloatParameter('C', minimum=0.2, maximum=5.0, distribution=Distribution.LOGUNIFORM),
            sk.FloatParameter('tol', minimum=0, maximum=1),
            sk.ConstantParameter('class_weight', value='balanced', optional=True),
        ]

        return parameters, []


class SVC(BaseSVC, OptimizableSVC):
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize an :class:`.SVC` estimator."""

        parameters, constraints = super().make_parameters_and_constraints(sk, **kwargs)

        parameters.extend([
            sk.FloatOrAuto('gamma', minimum=1.0e-5, maximum=1, distribution=Distribution.LOGUNIFORM),
            sk.CategoricalParameter('kernel', values=['linear', 'poly', 'rbf', 'sigmoid']),
            sk.IntParameter('degree', minimum=2, maximum=10, distribution=Distribution.LOGUNIFORM),
            sk.FloatParameter('coef0', minimum=0, maximum=1),
            sk.BoolParameter('shrinking')
        ])

        return parameters, constraints


class LinearSVC(BaseLinearSVC, OptimizableSVC):
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize a :class:`.LinearSVC` estimator."""

        parameters, constraints = super().make_parameters_and_constraints(sk, **kwargs)

        dual = sk.BoolParameter('dual', optional=True)
        penalty = sk.CategoricalParameter('penalty', values=['l1', 'l2'], optional=True)
        loss = sk.CategoricalParameter('loss', values=['hinge', 'squared_hinge'], optional=True)
        multi_class = sk.CategoricalParameter('multi_class', values=['ovr', 'crammer_singer'])

        fit_intercept = sk.BoolParameter('fit_intercept')
        intercept_scaling = sk.FloatParameter('intercept_scaling', minimum=0, maximum=1, optional=True)

        parameters.extend([dual, penalty, loss, multi_class, fit_intercept, intercept_scaling])

        dual_penalty_and_loss_are_present = dual.is_present() & penalty.is_present() & loss.is_present()
        dual_penalty_and_loss_are_absent = dual.is_absent() & penalty.is_absent() & loss.is_absent()

        constraints.extend([
            Constraint(when=dual == True, then=penalty == 'l2'),
            Constraint(when=dual == False, then=loss == 'squared_hinge'),
            Constraint(when=multi_class == 'ovr', then=dual_penalty_and_loss_are_present),
            Constraint(when=multi_class == 'crammer_singer', then=dual_penalty_and_loss_are_absent),
            Constraint(when=fit_intercept == True, then=intercept_scaling.is_present()),
            Constraint(when=fit_intercept == False, then=intercept_scaling.is_absent()),
        ])

        return parameters, constraints
