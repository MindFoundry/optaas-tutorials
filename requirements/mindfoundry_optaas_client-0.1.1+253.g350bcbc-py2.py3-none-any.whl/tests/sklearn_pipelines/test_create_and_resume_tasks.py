from mindfoundry.optaas.client.client import Goal
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ensemble import RandomForestClassifier, \
    ExtraTreesClassifier
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ica import FastICA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.svc import LinearSVC
from mindfoundry.optaas.client.sklearn_pipelines.estimators.voting import VotingClassifier
from mindfoundry.optaas.client.sklearn_pipelines.mixin import optional_step, optional_choice, \
    nested_pipeline, optional_nested_pipeline
from mindfoundry.optaas.client.sklearn_pipelines.utils import MissingArgumentError
from tests.sklearn_pipelines.utils import SklearnTest, MockClientTest


class TestCreate(SklearnTest):
    def test_create_sklearn_task(self):
        estimators = [
            ('reduce_dim', optional_choice(
                PCA(whiten=True, n_components=2),
                nested_pipeline([
                    ('ica', FastICA(n_components=3)),
                    ('clf', LinearSVC(penalty='l1', dual=False, tol=0.3))
                ])
            )),
            ('clf', RandomForestClassifier(min_samples_leaf=13)),
            ('clf2', optional_nested_pipeline([
                ('extra_trees', ExtraTreesClassifier(min_samples_leaf=17)),
            ]))
        ]
        user_defined_data = [{
            'my': 'data',
            'here': [1, 2, 3]
        }, 'a', 'b', 'c']
        task = self.client.create_sklearn_task(title='Sklearn Test', estimators=estimators, feature_count=9,
                                               random_seed=123, max_wait_time=4, initial_configurations=7,
                                               goal=Goal.max, user_defined_data=user_defined_data)

        task.refresh()
        self.assertEqual(0, task.number_of_iterations)
        self.assertEqual(user_defined_data, task.user_defined_data)
        self.assertEqual('running', task.status)


class TestResume(SklearnTest):
    def test_resume_sklearn_task(self):
        estimators = [
            ('reduce_dim', optional_step(BasePCA(whiten=True, n_components=2))),
            ('vt', VotingClassifier([
                ('rf', RandomForestClassifier()),
                ('et', ExtraTreesClassifier())
            ]))
        ]
        task = self.create_task(estimators)

        configuration = task.generate_configurations()[0]
        score = self.calculate_score(task, configuration)

        resumed_task = self.client.get_sklearn_task(task.id, estimators)
        next_configuration = resumed_task.record_result(configuration, score)
        next_score = self.calculate_score(resumed_task, next_configuration)
        resumed_task.record_result(next_configuration, next_score)

        resumed_task.refresh()
        self.assertEqual(2, resumed_task.number_of_iterations)
        self.assertEqual('running', resumed_task.status)


class TestValidation(MockClientTest):
    def test_PCA_without_feature_count(self):
        estimators = [('reduce_dim', PCA())]
        with self.assertRaisesRegex(MissingArgumentError,
                                    "feature_count is required in kwargs in order to optimize PCA"):
            self.create_mock_task(estimators)

    def test_space_in_estimator_name_is_replaced(self):
        estimators = [
            ('random forest', RandomForestClassifier()),
            ('randomer  forest', RandomForestClassifier()),
        ]
        task = self.create_mock_task(estimators)
        wrong_ids = [p for p in task.parameters if ' ' in p['id'] or '__' in p['id']]
        self.assertEqual(0, len(wrong_ids), f"These ids contain a space or double underscore: {wrong_ids}")
