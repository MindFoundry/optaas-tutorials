from decorator import contextmanager

from mindfoundry.optaas.client.sklearn_pipelines.estimators.ica import FastICA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.svc import LinearSVC
from mindfoundry.optaas.client.sklearn_pipelines.mixin import optional_step, choice, optional_choice
from tests.sklearn_pipelines.utils import MockClientTest


class TestDefaults(MockClientTest):
    def test_no_defaults_specified(self):
        with self.use_estimators(PCA(), LinearSVC()):
            self.assert_n_components_default(None)
            self.assert_tol_default(0.0001)

    @contextmanager
    def use_estimators(self, pca, svc=None):
        estimators = [('rd', pca)]
        if svc:
            estimators.append(('svc', svc))
        self.task = self.create_mock_task(estimators, feature_count=100, unrelated_arg='abc')
        yield

    def assert_n_components_default(self, expected_default, expected_type=None):
        with self.subTest('n_components'):
            n_components_choice = self.find_parameter('rd', 'n_components')
            if expected_default is None:
                self.assertFalse(n_components_choice['includeInDefault'])
            else:
                self.assertTrue(n_components_choice['default'].startswith('#'))
                n_components_default_id = n_components_choice['default'][1:]
                n_components = next(p for p in n_components_choice['choices'] if p['id'] == n_components_default_id)

                self.assertEqual(expected_type, n_components['type'])
                if expected_type == 'constant':
                    self.assertEqual(expected_default, n_components['value'])
                    self.assertNotIn('default', n_components)
                else:
                    self.assertEqual(expected_default, n_components['default'])

    def assert_tol_default(self, expected_default):
        with self.subTest('tol'):
            tol = self.find_parameter('svc', 'tol')
            self.assertEqual(expected_default, tol['default'])

    def test_n_components_int_and_tol(self):
        with self.use_estimators(PCA(n_components=7), LinearSVC(tol=0.123)):
            self.assert_n_components_default(7, 'integer')
            self.assert_tol_default(0.123)

    def test_n_components_mle(self):
        with self.use_estimators(PCA(n_components='mle')):
            self.assert_n_components_default('mle', 'constant')

    def test_n_components_float(self):
        with self.use_estimators(PCA(n_components=0.123)):
            self.assert_n_components_default(0.123, 'number')

    def test_n_components_invalid(self):
        with self.assertRaisesRegex(ValueError,
                                    "invalid_string is not a valid default value for parameter 'n_components'"):
            self.create_mock_task([('pca', PCA(n_components='invalid_string'))], feature_count=9)

    def test_optional_pca(self):
        with self.use_estimators(optional_step(PCA())):
            self.assert_n_components_default(None)

    def test_optional_pca_with_int(self):
        with self.use_estimators(optional_step(PCA(n_components=2))):
            self.assert_n_components_default(2, 'integer')

    def test_choice(self):
        with self.use_estimators(
                choice(
                    PCA(n_components=1),
                    BasePCA(n_components=2),
                    optional_step(FastICA(n_components=3))
                ),
                LinearSVC(tol=0.123)
        ):
            self.assertEqual(2, len(self.task.parameters))
            self.assert_tol_default(0.123)

            choice_parameter = next(p for p in self.task.parameters if p['name'] == 'rd')
            self.assertEqual('choice', choice_parameter['type'])

            choices = choice_parameter['choices']
            self.assertEqual(3, len(choices))

            with self.subTest('PCA'):
                pca = choices[0]
                n_components_choice = next(p for p in pca['items'] if p['name'] == 'n_components')
                n_components_default_id = n_components_choice['default'][1:]
                n_components = next(p for p in n_components_choice['choices'] if p['id'] == n_components_default_id)
                self.assertEqual(1, n_components['default'])

            with self.subTest('BasePCA'):
                self.assertEqual([], choices[1]['items'])

            with self.subTest('ICA'):
                ica = choices[2]
                self.assertTrue(ica['optional'])
                n_components = next(p for p in ica['items'] if p['name'] == 'n_components')
                self.assertEqual(3, n_components['default'])

    def test_optional_choice(self):
        with self.use_estimators(
                optional_choice(
                    PCA(n_components=1),
                    FastICA(n_components=2)
                ),
                LinearSVC(tol=0.123)
        ):
            self.assertEqual(2, len(self.task.parameters))
            self.assert_tol_default(0.123)

            choice_parameter = next(p for p in self.task.parameters if p['name'] == 'rd')
            self.assertEqual('choice', choice_parameter['type'])
            self.assertTrue(choice_parameter['optional'])

            choices = choice_parameter['choices']
            self.assertEqual(2, len(choices))

            with self.subTest('PCA'):
                pca = choices[0]
                n_components_choice = next(p for p in pca['items'] if p['name'] == 'n_components')
                n_components_default_id = n_components_choice['default'][1:]
                n_components = next(p for p in n_components_choice['choices'] if p['id'] == n_components_default_id)
                self.assertEqual(1, n_components['default'])

            with self.subTest('ICA'):
                ica = choices[1]
                n_components = next(p for p in ica['items'] if p['name'] == 'n_components')
                self.assertEqual(2, n_components['default'])