from sklearn.decomposition import PCA as BasePCA

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker
from mindfoundry.optaas.client.sklearn_pipelines.utils import ParametersAndConstraints, SMALLEST_NUMBER_ABOVE_ZERO, \
    LARGEST_NUMBER_BELOW_ONE


class PCA(BasePCA, OptimizableBaseEstimator):
    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs) -> ParametersAndConstraints:
        """Generates :class:`Parameters <.Parameter>` and :class:`Constraints <.Constraint>` to optimize a :class:`.PCA` estimator.

        Args:
            feature_count (int): Total number of features in your dataset.
        """

        feature_count = self._get_required_kwarg(kwargs, 'feature_count')

        mle = sk.ConstantParameter('n_components_mle', value='mle')
        n_components_int = sk.IntParameter('n_components_int', minimum=1, maximum=feature_count)
        n_components_float = sk.FloatParameter('n_components_float', minimum=SMALLEST_NUMBER_ABOVE_ZERO,
                                               maximum=LARGEST_NUMBER_BELOW_ONE)
        n_components = sk.ChoiceParameter('n_components', optional=True,
                                          choices=[n_components_int, n_components_float, mle])

        svd_solver = sk.CategoricalParameter("svd_solver", values=['arpack', 'auto', 'full', 'randomized'])
        whiten = sk.BoolParameter('whiten')
        tol = sk.FloatParameter('tol', minimum=0, maximum=1, optional=True)
        iterated_power = sk.IntOrAuto('iterated_power', minimum=0, maximum=99)

        return [svd_solver, n_components, whiten, tol, iterated_power], [
            Constraint(when=svd_solver == 'arpack', then=(n_components_int < feature_count) & tol.is_present()),
            Constraint(when=(svd_solver == 'auto') | (svd_solver == 'randomized'),
                       then=n_components.is_absent() | (n_components == n_components_int))
        ]
