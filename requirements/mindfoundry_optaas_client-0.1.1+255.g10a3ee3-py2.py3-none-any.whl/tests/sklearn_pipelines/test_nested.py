from sklearn.pipeline import Pipeline
from sklearn.preprocessing import Normalizer

from mindfoundry.optaas.client.sklearn_pipelines.estimators.ensemble import RandomForestClassifier
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ica import FastICA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.pca import PCA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.svc import LinearSVC
from mindfoundry.optaas.client.sklearn_pipelines.mixin import choice, nested_pipeline, optional_nested_pipeline
from tests.sklearn_pipelines.utils import MockClientTest
from tests.utils import MockConfiguration


class TestNested(MockClientTest):
    def test_nested_pipeline(self):
        n_components = 13
        feature_count = 20

        task = self.create_mock_task([
            ('choice', choice(
                LinearSVC(),
                nested_pipeline([
                    ('normalize', Normalizer()),
                    ('reduce_dim', choice(
                        PCA(),
                        FastICA()
                    )),
                    ('classify', optional_nested_pipeline([
                        ('normalize', Normalizer()),
                        ('choice', choice(
                            LinearSVC(),
                            RandomForestClassifier()
                        )),
                    ]))
                ])
            ))
        ], feature_count=feature_count)

        configuration = MockConfiguration(values={
            'choice': {
                '1': {
                    'normalize': {},
                    'reduce_dim': {
                        '0': {
                            'n_components': {'n_components_int': n_components},
                            'iterated_power': {'iterated_power_int': 3},
                            'svd_solver': 'auto',
                            'tol': 0.2,
                            'whiten': True
                        }
                    },
                    'classify': {
                        'normalize': {},
                        'choice': {
                            '0': {
                                'C': 0.2,
                                'fit_intercept': False,
                                'multi_class': 'crammer_singer',
                                'tol': 0.3,
                            },
                        },
                    }
                }
            }
        })

        linear_svc_params = LinearSVC(C=0.2, fit_intercept=False, multi_class='crammer_singer', tol=0.3,
                                      dual=None, intercept_scaling=None, penalty=None, loss=None).get_params()
        pca_params = PCA(n_components=n_components, whiten=True, iterated_power=3, tol=0.2).get_params()
        normalize_params = Normalizer().get_params()

        pipe = task.make_pipeline(configuration)
        self.assertEqual(1, len(pipe.steps))

        nested = pipe.steps[0][1]
        self.assertIsInstance(nested, Pipeline)
        self.assertEqual(3, len(nested.steps))

        self.assertIsInstance(nested.steps[0][1], Normalizer)
        self.assertEqual(normalize_params, nested.steps[0][1].get_params())

        self.assertIsInstance(nested.steps[1][1], PCA)
        self.assertEqual(pca_params, nested.steps[1][1].get_params())

        sub_nested = nested.steps[2][1]
        self.assertIsInstance(sub_nested, Pipeline)
        self.assertEqual(2, len(sub_nested.steps))

        self.assertIsInstance(sub_nested.steps[0][1], Normalizer)
        self.assertEqual(normalize_params, sub_nested.steps[0][1].get_params())

        self.assertIsInstance(sub_nested.steps[1][1], LinearSVC)
        self.assertEqual(linear_svc_params, sub_nested.steps[1][1].get_params())
