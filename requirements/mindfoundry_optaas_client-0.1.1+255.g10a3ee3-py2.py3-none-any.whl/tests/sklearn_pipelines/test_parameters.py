from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import BoolParameter, CategoricalParameter
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ada_boost import AdaBoostClassifier, AdaBoostRegressor
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ensemble import RandomForestClassifier, \
    RandomForestRegressor, ExtraTreesClassifier, ExtraTreesRegressor, GradientBoostingClassifier, \
    GradientBoostingRegressor, DecisionTreeClassifier, DecisionTreeRegressor
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ica import FastICA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.k_neighbors import KNeighborsClassifier, KNeighborsRegressor
from mindfoundry.optaas.client.sklearn_pipelines.estimators.linear_model import Lasso, Ridge
from mindfoundry.optaas.client.sklearn_pipelines.estimators.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.svc import SVC, LinearSVC
from mindfoundry.optaas.client.sklearn_pipelines.estimators.voting import VotingClassifier
from mindfoundry.optaas.client.sklearn_pipelines.estimators.xgboost import XGBClassifier
from mindfoundry.optaas.client.sklearn_pipelines.mixin import optional_step, optional_choice, choice, nested_pipeline, \
    optional_nested_pipeline
from tests.sklearn_pipelines.utils import MockClientTest


class TestParameters(MockClientTest):
    excluded_forest_parameters = ['random_state', 'verbose', 'warm_start', 'n_jobs', 'class_weight',
                                  'min_impurity_split']
    excluded_parameters = {
        'ada_boost': ['random_state', 'base_estimator'],
        'ada_boost_reg': ['random_state', 'base_estimator'],
        'grad_boost': ['random_state', 'min_impurity_split', 'init', 'verbose', 'warm_start'],
        'grad_boost_reg': ['random_state', 'min_impurity_split', 'init', 'warm_start', 'verbose'],
        'pca': ['copy', 'random_state'],
        'opt_pca': ['copy', 'random_state'],
        'ica': ['copy', 'random_state', 'fun_args', 'max_iter', 'w_init'],
        'svc': ['random_state', 'max_iter', 'verbose', 'probability', 'cache_size', 'decision_function_shape'],
        'linear_svc': ['random_state', 'max_iter', 'verbose'],
        'my_svc': ['random_state', 'max_iter', 'verbose'],
        'rf': excluded_forest_parameters,
        'rf_reg': excluded_forest_parameters,
        'extr': excluded_forest_parameters,
        'extr_reg': excluded_forest_parameters,
        'voting': ['vet__' + p for p in excluded_forest_parameters] +
                  ['vrf__' + p for p in excluded_forest_parameters] +
                  ['vet', 'vrf', 'estimators', 'flatten_transform', 'n_jobs'],
        'dtc': ['random_state', 'min_impurity_split', 'class_weight'],
        'dtr': ['random_state', 'min_impurity_split'],
        'kn': ['metric', 'n_jobs', 'metric_params', 'leaf_size'],
        'kn_reg': ['metric', 'n_jobs', 'metric_params', 'leaf_size'],
        'xg': ['silent', 'nthread', 'missing', 'seed', 'random_state', 'n_jobs'],
        'lasso': ['max_iter', 'positive', 'random_state', 'precompute', 'fit_intercept', 'selection', 'tol', 'copy_X',
                  'normalize', 'warm_start'],
        'ridge': ['max_iter', 'positive', 'random_state', 'precompute', 'fit_intercept', 'selection', 'tol', 'copy_X',
                  'normalize', 'warm_start', 'solver']
    }

    def test_all_required_parameters_are_generated_with_correct_names(self):
        estimators = [
            ('pca', PCA()),
            ('opt_pca', optional_step(PCA())),
            ('ica', FastICA()),
            ('svc', SVC()),
            ('linear_svc', LinearSVC()),
            ('rf', RandomForestClassifier()),
            ('rf_reg', RandomForestRegressor()),
            ('extr', ExtraTreesClassifier()),
            ('extr_reg', ExtraTreesRegressor()),
            ('voting', VotingClassifier([
                ('vrf', RandomForestClassifier()),
                ('vet', ExtraTreesClassifier())
            ])),
            ('ada_boost', AdaBoostClassifier()),
            ('ada_boost_reg', AdaBoostRegressor()),
            ('grad_boost', GradientBoostingClassifier()),
            ('grad_boost_reg', GradientBoostingRegressor()),
            ('dtc', DecisionTreeClassifier()),
            ('dtr', DecisionTreeRegressor()),
            ('kn', KNeighborsClassifier()),
            ('kn_reg', KNeighborsRegressor()),
            ('xg', XGBClassifier()),
            ('lasso', Lasso()),
            ('ridge', Ridge())
        ]

        dummy_bool = BoolParameter('dummy bool', id='dummy_bool', optional=True)
        dummy_cat = CategoricalParameter('dummy string', id='dummy_string', values=['a', 'b', 'c'])
        additional_parameters = [dummy_bool, dummy_cat]
        additional_constraints = [
            Constraint(when=dummy_bool == True, then=dummy_cat == 'b')
        ]

        self.task = self.create_mock_task(estimators,
                                          additional_parameters=additional_parameters,
                                          additional_constraints=additional_constraints,
                                          feature_count=5, class_count=2)

        with self.subTest('root parameters'):
            pipeline_params = self.task.parameters[0]['items']
            expected_root_parameters = [{
                'name': 'pipeline',
                'id': self.task.parameters[0]['id'],
                'type': 'group',
                'items': pipeline_params
            }, {
                'name': 'additional',
                'id': self.task.parameters[1]['id'],
                'type': 'group',
                'items': [p.to_json() for p in additional_parameters]
            }]
            self.assertEqual(expected_root_parameters, self.task.parameters)

        with self.subTest('additional constraints'):
            for constraint in additional_constraints:
                self.assertIn(constraint.to_optaas_expression(), self.task.constraints)

        for estimator_name, estimator in estimators:
            with self.subTest(estimator_name):
                self.verify_parameters(estimator_name, estimator)

    def verify_parameters(self, estimator_name, estimator):
        root_parameter = next(p for p in self.task.parameters[0]['items'] if p['name'] == estimator_name)
        required_parameter_names = {p for p in estimator.get_params()
                                    if p not in self.excluded_parameters[estimator_name]}
        generated_parameter_names = {parameter['name'] for parameter in root_parameter['items']}

        missing_parameter_names = required_parameter_names - generated_parameter_names
        excess_parameter_names = generated_parameter_names - required_parameter_names
        if missing_parameter_names or excess_parameter_names:
            self.fail(f'Missing parameters: {missing_parameter_names}   Excess parameters: {excess_parameter_names}')

    def test_estimator_that_extends_predefined_class(self):
        class MyLinearSVC(LinearSVC):
            pass

        estimators = [('my_svc', MyLinearSVC())]
        self.task = self.create_mock_task(estimators)
        self.verify_parameters('my_svc', LinearSVC())

    def test_feature_count_is_used_in_PCA(self):
        feature_count = 999
        estimators = [('pca', PCA())]
        self.task = self.create_mock_task(estimators, feature_count=feature_count)
        n_components_choice = self.find_parameter('pca', 'n_components')
        n_components_int = next(p for p in n_components_choice['choices'] if p['name'] == 'n_components_int')
        self.assertEqual(feature_count, n_components_int['maximum'])

    def test_voting_weights(self):
        self.assert_correct_voting_weights('forest only', [
            ('rf', RandomForestClassifier()),
        ])
        self.assert_correct_voting_weights('trees only', [
            ('extr', ExtraTreesClassifier())
        ])
        self.assert_correct_voting_weights('both', [
            ('forest', RandomForestClassifier()),
            ('trees', ExtraTreesClassifier())
        ])

    def assert_correct_voting_weights(self, description, voting_estimators):
        with self.subTest(description):
            estimators = [('voting', VotingClassifier(voting_estimators))]
            self.task = self.create_mock_task(estimators)
            weights = self.find_parameter('voting', 'weights')
            self.assertEqual(len(voting_estimators), len(weights['items']))

    def test_optional(self):
        feature_count = 9
        task_with_pca = self.create_mock_task([('reduce_dim', PCA())], feature_count=feature_count)
        task_with_optional_pca = self.create_mock_task([('reduce_dim', optional_step(PCA()))],
                                                       feature_count=feature_count)

        expected_parameter = {
            'name': 'reduce_dim',
            'id': 'reduce_dim',
            'type': 'group',
            'optional': True,
            'items': task_with_pca.parameters[0]['items']
        }
        self.assertEqual([expected_parameter], task_with_optional_pca.parameters)
        self.assertEqual(task_with_pca.constraints, task_with_optional_pca.constraints)

    def test_optional_non_optimizable(self):
        task = self.create_mock_task([('reduce_dim', optional_step(BasePCA()))])

        expected_parameter = {
            'name': 'reduce_dim',
            'id': 'reduce_dim',
            'type': 'group',
            'optional': True,
            'items': []
        }
        self.assertEqual([expected_parameter], task.parameters)
        self.assertEqual([], task.constraints)

    def test_choice(self):
        self.assert_choice_parameters_and_constraints(optional=False)

    def assert_choice_parameters_and_constraints(self, optional: bool):
        if optional:
            estimator = optional_choice(PCA(), FastICA(), BasePCA())
        else:
            estimator = choice(PCA(), FastICA(), BasePCA())

        feature_count = 9
        task_with_choice = self.create_mock_task([('rd', estimator)], feature_count=feature_count)

        task_with_pca = self.create_mock_task([('rd__0', PCA())], feature_count=feature_count)
        task_with_ica = self.create_mock_task([('rd__1', FastICA())], feature_count=feature_count)

        expected_parameter = {
            'name': 'rd',
            'id': 'rd',
            'type': 'choice',
            'choices': [{
                'id': 'rd__0',
                'name': '0',
                'type': 'group',
                'items': task_with_pca.parameters[0]['items']
            }, {
                'id': 'rd__1',
                'name': '1',
                'type': 'group',
                'items': task_with_ica.parameters[0]['items']
            }, {
                'id': 'rd__2',
                'name': '2',
                'type': 'group',
                'items': []
            }]
        }
        if optional:
            expected_parameter['optional'] = True

        self.assertEqual([expected_parameter], task_with_choice.parameters)
        self.assertEqual(task_with_pca.constraints + task_with_ica.constraints, task_with_choice.constraints)

    def test_optional_choice(self):
        self.assert_choice_parameters_and_constraints(optional=True)

    def test_nested_pipelines(self):
        feature_count = 9
        task_with_pca = self.create_mock_task([('choice-of-pipelines__0__pca', PCA())], feature_count=feature_count)
        task_with_forest = self.create_mock_task([('choice-of-pipelines__0__clf', RandomForestClassifier())])
        task_with_opt_ica = self.create_mock_task([('choice-of-pipelines__1__opt-ica', optional_step(FastICA()))],
                                                  feature_count=feature_count)
        task_with_trees = self.create_mock_task([('choice-of-pipelines__1__clf', ExtraTreesClassifier())])
        task_with_svc = self.create_mock_task([('choice-of-pipelines__1__double-nested__svc', LinearSVC())])

        task_with_nested = self.create_mock_task([
            ('choice of pipelines', choice(
                nested_pipeline([
                    ('pca', PCA()),
                    ('clf', RandomForestClassifier())
                ]),
                optional_nested_pipeline([
                    ('opt ica', optional_step(FastICA())),
                    ('clf', ExtraTreesClassifier()),  # NB intentionally uses the same name as RandomForest above
                    ('double nested', nested_pipeline([
                        ('svc', LinearSVC())
                    ]))
                ])
            ))
        ], feature_count=feature_count)

        expected_parameter = {
            'name': 'choice of pipelines',
            'id': 'choice-of-pipelines',
            'type': 'choice',
            'choices': [{
                'name': '0',
                'id': 'choice-of-pipelines__0',
                'type': 'group',
                'items': [{
                    'name': 'pca',
                    'id': 'choice-of-pipelines__0__pca',
                    'type': 'group',
                    'items': task_with_pca.parameters[0]['items']
                }, {
                    'name': 'clf',
                    'id': 'choice-of-pipelines__0__clf',
                    'type': 'group',
                    'items': task_with_forest.parameters[0]['items']
                }]
            }, {
                'name': '1',
                'id': 'choice-of-pipelines__1',
                'type': 'group',
                'optional': True,
                'items': [{
                    'name': 'opt ica',
                    'id': 'choice-of-pipelines__1__opt-ica',
                    'type': 'group',
                    'optional': True,
                    'items': task_with_opt_ica.parameters[0]['items']
                }, {
                    'name': 'clf',
                    'id': 'choice-of-pipelines__1__clf',
                    'type': 'group',
                    'items': task_with_trees.parameters[0]['items']
                }, {
                    'name': 'double nested',
                    'id': 'choice-of-pipelines__1__double-nested',
                    'type': 'group',
                    'items': [{
                        'name': 'svc',
                        'id': 'choice-of-pipelines__1__double-nested__svc',
                        'type': 'group',
                        'items': task_with_svc.parameters[0]['items']
                    }]
                }]
            }]
        }
        self.assertEqual([expected_parameter], task_with_nested.parameters)

        expected_constraints = task_with_pca.constraints + task_with_forest.constraints \
                               + task_with_opt_ica.constraints + task_with_trees.constraints \
                               + task_with_svc.constraints
        self.assertEqual(expected_constraints, task_with_nested.constraints)
