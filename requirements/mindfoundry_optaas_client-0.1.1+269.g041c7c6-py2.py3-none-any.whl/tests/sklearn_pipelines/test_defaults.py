from typing import Any

from decorator import contextmanager

from mindfoundry.optaas.client.sklearn_pipelines.estimators.ica import FastICA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.svc import LinearSVC
from mindfoundry.optaas.client.sklearn_pipelines.mixin import optional_step, choice, optional_choice, \
    OptimizableBaseEstimator
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker
from tests.sklearn_pipelines.utils import MockClientTest


class MyEstimator(OptimizableBaseEstimator):
    def __init__(self, choice: Any = 5):
        self.choice = choice

    def make_parameters_and_constraints(self, sk: SklearnParameterMaker, **kwargs):
        int_param = sk.IntParameter('int_param', minimum=1, maximum=10)
        float_param = sk.FloatParameter('float_param', minimum=0, maximum=1)
        const_param = sk.ConstantParameter('const_param', value='a constant')
        cat_param = sk.CategoricalParameter('cat_param', values=['abc', 'defg', 'hijk', 'lmnop'])
        return [
                   sk.ChoiceParameter('choice', choices=[int_param, float_param, const_param, cat_param])
               ], []


class TestDefaults(MockClientTest):
    def test_no_defaults_specified(self):
        with self.use_estimators(MyEstimator(), LinearSVC()):
            self.assert_choice_default(5, 'integer')
            self.assert_tol_default(0.0001)

    @contextmanager
    def use_estimators(self, my_estimator, svc=None):
        estimators = [('my', my_estimator)]
        if svc:
            estimators.append(('svc', svc))
        self.task = self.create_mock_task(estimators, feature_count=100)
        yield

    def assert_choice_default(self, expected_default, expected_type=None):
        with self.subTest('choice'):
            choice = self.find_parameter('my', 'choice')
            if expected_default is None:
                self.assertFalse(choice['includeInDefault'])
            else:
                self.assertTrue(choice['default'].startswith('#'))
                choice_default_id = choice['default'][1:]
                choice_default = next(p for p in choice['choices'] if p['id'] == choice_default_id)

                self.assertEqual(expected_type, choice_default['type'])
                if expected_type == 'constant':
                    self.assertEqual(expected_default, choice_default['value'])
                    self.assertNotIn('default', choice_default)
                else:
                    self.assertEqual(expected_default, choice_default['default'])

    def assert_tol_default(self, expected_default):
        with self.subTest('tol'):
            tol = self.find_parameter('svc', 'tol')
            self.assertEqual(expected_default, tol['default'])

    def test_int_and_tol(self):
        with self.use_estimators(MyEstimator(choice=1), LinearSVC(tol=0.123)):
            self.assert_choice_default(1, 'integer')
            self.assert_tol_default(0.123)

    def test_float(self):
        with self.use_estimators(MyEstimator(choice=1.0)):
            self.assert_choice_default(1.0, 'number')

    def test_const(self):
        with self.use_estimators(MyEstimator(choice='a constant')):
            self.assert_choice_default('a constant', 'constant')

    def test_cat(self):
        with self.use_estimators(MyEstimator(choice='hijk')):
            self.assert_choice_default('hijk', 'categorical')

    def test_invalid(self):
        with self.assertRaisesRegex(ValueError,
                                    "invalid_string is not a valid default value for parameter 'choice'"):
            self.create_mock_task([('my', MyEstimator(choice='invalid_string'))], feature_count=9)

    def test_optional_pca(self):
        with self.use_estimators(optional_step(MyEstimator())):
            self.assert_choice_default(5, 'integer')

    def test_optional_pca_with_float(self):
        with self.use_estimators(optional_step(MyEstimator(choice=0.3))):
            self.assert_choice_default(0.3, 'number')

    def test_choice(self):
        with self.use_estimators(
                choice(
                    PCA(n_components=1),
                    BasePCA(n_components=2),
                    optional_step(FastICA(n_components=3))
                ),
                LinearSVC(tol=0.123)
        ):
            pipeline_parameters = self.task.parameters[0]['items']
            self.assertEqual(2, len(pipeline_parameters))
            self.assert_tol_default(0.123)

            choice_parameter = next(p for p in pipeline_parameters if p['name'] == 'my')
            self.assertEqual('choice', choice_parameter['type'])

            choices = choice_parameter['choices']
            self.assertEqual(3, len(choices))

            with self.subTest('PCA'):
                pca = choices[0]
                n_components = next(p for p in pca['items'] if p['name'] == 'n_components')
                self.assertEqual(1, n_components['default'])

            with self.subTest('BasePCA'):
                self.assertEqual([], choices[1]['items'])

            with self.subTest('ICA'):
                ica = choices[2]
                self.assertTrue(ica['optional'])
                n_components = next(p for p in ica['items'] if p['name'] == 'n_components')
                self.assertEqual(3, n_components['default'])

    def test_optional_choice(self):
        with self.use_estimators(
                optional_choice(
                    PCA(n_components=1),
                    FastICA(n_components=2)
                ),
                LinearSVC(tol=0.123)
        ):
            pipeline_parameters = self.task.parameters[0]['items']
            self.assertEqual(2, len(pipeline_parameters))
            self.assert_tol_default(0.123)

            choice_parameter = next(p for p in pipeline_parameters if p['name'] == 'my')
            self.assertEqual('choice', choice_parameter['type'])
            self.assertTrue(choice_parameter['optional'])

            choices = choice_parameter['choices']
            self.assertEqual(2, len(choices))

            with self.subTest('PCA'):
                pca = choices[0]
                n_components = next(p for p in pca['items'] if p['name'] == 'n_components')
                self.assertEqual(1, n_components['default'])

            with self.subTest('ICA'):
                ica = choices[1]
                n_components = next(p for p in ica['items'] if p['name'] == 'n_components')
                self.assertEqual(2, n_components['default'])
