from random import randint

from sklearn import datasets

from mindfoundry.optaas.client.constraint import Constraint
from mindfoundry.optaas.client.parameter import BoolParameter
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ada_boost import AdaBoostClassifier, AdaBoostRegressor
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ensemble import RandomForestClassifier, \
    ExtraTreesClassifier, ExtraTreesRegressor, RandomForestRegressor, DecisionTreeClassifier, DecisionTreeRegressor, \
    GradientBoostingRegressor, GradientBoostingClassifier
from mindfoundry.optaas.client.sklearn_pipelines.estimators.ica import FastICA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.k_neighbors import KNeighborsClassifier, KNeighborsRegressor
from mindfoundry.optaas.client.sklearn_pipelines.estimators.linear_model import Ridge, Lasso
from mindfoundry.optaas.client.sklearn_pipelines.estimators.pca import PCA, BasePCA
from mindfoundry.optaas.client.sklearn_pipelines.estimators.svc import LinearSVC, SVC,BaseLinearSVC
from mindfoundry.optaas.client.sklearn_pipelines.estimators.voting import VotingClassifier
from mindfoundry.optaas.client.sklearn_pipelines.estimators.xgboost import XGBClassifier
from mindfoundry.optaas.client.sklearn_pipelines.mixin import OptimizableBaseEstimator, optional_step, \
    OptionalStepMixin, choice, nested_pipeline, optional_nested_pipeline
from mindfoundry.optaas.client.sklearn_pipelines.parameter_maker import SklearnParameterMaker
from mindfoundry.optaas.client.sklearn_pipelines.utils import ParametersAndConstraints
from tests.sklearn_pipelines.utils import SklearnTest


class TestEndToEnd(SklearnTest):
    def test_PCA_and_boosters(self):
        dummy_bool = BoolParameter('dummy bool', id='dummy_bool')

        task = self.optimize_pipeline([
            ('reduce_dim', optional_step(PCA())),
            ('clf', choice(
                XGBClassifier(),
                AdaBoostClassifier(),
                GradientBoostingClassifier(),
            ))
        ], additional_parameters=[dummy_bool], additional_constraints=[Constraint(dummy_bool != True)])

        with self.assertRaisesOPTaaSError(400, "Configuration violates constraint: #dummy_bool != true"):
            task.add_user_defined_configuration({
                'pipeline': {
                    'clf': {
                        '1': {
                            'n_estimators': 10,
                            'learning_rate': 2.5,
                            'algorithm': 'SAMME.R'
                        }
                    },
                },
                'additional': {
                    'dummy bool': True
                }
            })

        self.verify_valid_configuration(task, {
            'pipeline': {
                'clf': {
                    '1': {
                        'n_estimators': 10,
                        'learning_rate': 2.5,
                        'algorithm': 'SAMME.R'
                    }
                },
                # PCA not present
            },
            'additional': {
                'dummy bool': False
            }
        })

        self.verify_valid_configuration(task, {
            'pipeline': {
                'clf': {
                    '1': {
                        'n_estimators': 125,
                        'learning_rate': 1.5,
                        'algorithm': 'SAMME'
                    }
                },
                'reduce_dim': {  # PCA present
                    'n_components': 1,
                    'whiten': True
                }
            },
            'additional': {
                'dummy bool': False
            }
        })

    def verify_valid_configuration(self, task, values):
        config = task.add_user_defined_configuration(values=values)
        self.assertEqual('user-defined', config.type)
        self.assertEqual(values, config.values)
        self.calculate_score(task, config)

    def test_nested_with_ICA_or_BasePCA_and_forests_and_trees(self):
        self.optimize_pipeline([
            ('choice', choice(
                nested_pipeline([
                    ('reduce-dim', FastICA()),
                    ('classify', RandomForestClassifier()),
                ]),
                nested_pipeline([
                    ('reduce dim', optional_nested_pipeline([
                        ('base pca', BasePCA())
                    ])),
                    ('classify', choice(
                        ExtraTreesClassifier(),
                        DecisionTreeClassifier(),
                        VotingClassifier([
                            ('rf', RandomForestClassifier()),
                            ('et', ExtraTreesClassifier())
                        ])
                    ))
                ]),
            ))
        ])

    def test_svc_or_neighbors(self):
        task = self.optimize_pipeline([
            ('clf', choice(
                SVC(),
                LinearSVC(),
                KNeighborsClassifier(),
            ))
        ])

    def test_user_defined(self):
        class UserDefinedEstimator(OptimizableBaseEstimator):
            test = self

            def __init__(self, int_param: int = 3, cat_param: str = None, float_param: float = 0.1,
                         non_optimizable_param=9):
                self.int_param = int_param
                self.cat_param = cat_param
                self.float_param = float_param
                self.non_optimizable_param = non_optimizable_param

            def make_parameters_and_constraints(self, sk: SklearnParameterMaker,
                                                **kwargs) -> ParametersAndConstraints:
                int_param = sk.IntParameter('int_param', minimum=1, maximum=10)
                float_param = sk.FloatParameter('float_param', minimum=0, maximum=1)
                cat_param = sk.CategoricalParameter('cat_param', values=['a', 'b', 'c', 'd'])
                constraints = [
                    Constraint(when=int_param == 2, then=cat_param != 'a'),
                    Constraint((float_param <= 0.2) | (float_param > 0.32))
                ]
                return [int_param, float_param, cat_param], constraints

            def fit(self, X, y=None, **fit_params):
                self.test.assertTrue(0 <= self.float_param <= 0.2 or 0.32 < self.float_param <= 1)
                self.test.assertIn(self.int_param, range(1, 11))
                if self.int_param == 2:
                    self.test.assertIn(self.cat_param, ['b', 'c', 'd'])
                else:
                    self.test.assertIn(self.cat_param, ['a', 'b', 'c', 'd'])
                self.test.assertIn(self.non_optimizable_param, [2, 3, 9])

                return self

            def predict(self, X):
                return [randint(0, 2) for _ in X]

            def transform(self, X):
                return X

        class OptionalUserDefinedEstimator(UserDefinedEstimator, OptionalStepMixin):
            pass

        self.optimize_pipeline([
            ('user_defined', UserDefinedEstimator(cat_param='c', non_optimizable_param=2)),
            ('optional', optional_step(UserDefinedEstimator(int_param=9, float_param=0.13))),
            ('optional_mixin', OptionalUserDefinedEstimator(cat_param='a', non_optimizable_param=3))
        ], ignore_score=True)

    def test_pca_solvers(self):
        self.initial_configurations = 3
        self.number_of_iterations = 6
        for svd_solver in ['full', 'randomized', 'arpack']:
            with self.subTest(svd_solver):
                self.optimize_pipeline([
                    ('pca', PCA(svd_solver=svd_solver)),
                    ('clf', BaseLinearSVC()),
                ])


class TestEndToEndRegressors(SklearnTest):
    scoring = 'explained_variance'
    dataset = datasets.load_boston()
    expected_best_non_default_score = 0.5

    def test_forest_and_neighbour_regressors(self):
        self.optimize_pipeline([
            ('regressor', choice(
                RandomForestRegressor(),
                ExtraTreesRegressor(),
                DecisionTreeRegressor(),
                KNeighborsRegressor(),
            ))
        ])

    def test_other_regressors(self):
        self.optimize_pipeline([
            ('regressor', choice(
                AdaBoostRegressor(),
                GradientBoostingRegressor(),
                Ridge(),
                Lasso()
            ))
        ])
