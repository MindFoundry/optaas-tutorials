Optimizer as a Service - Python Client
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

OPTaaS is an optimization service developed by Mind Foundry.

This Python client makes it easier to interact with the API and integrate with other Python libraries such as sklearn.

Quick start::

    from mindfoundry.optaas.client.client import OPTaaSClient
    from mindfoundry.optaas.client.parameter import FloatParameter, CategoricalParameter

    client = OPTaaSClient(YOUR_OPTAAS_URL, YOUR_OPTAAS_API_KEY)

    parameters = [
        FloatParameter(name='my_float', minimum=0.5, maximum=9.9),
        CategoricalParameter(name='my_categorical', values=['a', 'b', 'c'])
    ]

    task = client.create_task('My Task', parameters)

    configuration = task.generate_configuration()
    score = calculate_score(configuration.values)  # your scoring function
    next_configuration = task.record_result(configuration, score)



