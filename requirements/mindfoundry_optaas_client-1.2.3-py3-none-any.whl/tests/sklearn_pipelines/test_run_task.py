from sklearn.model_selection import cross_val_score

from mindfoundry.optaas.client.sklearn_pipelines.estimators.svc import SVC
from tests.sklearn_pipelines.utils import SklearnTest


class TestRunTask(SklearnTest):
    def scoring_function(self, pipeline):
        scores = cross_val_score(pipeline, self.data, self.target, scoring=self.scoring)
        return scores.mean()

    def test_with_threshold(self):
        self.run_task_and_assert_output(max_iterations=25, score_threshold=0.9869)

    def test_without_threshold(self):
        self.run_task_and_assert_output(max_iterations=5)

    def run_task_and_assert_output(self, max_iterations, score_threshold=None):
        task = self.create_task(
            estimators=[
                ('svc', SVC())
            ]
        )

        best_result, best_pipeline = task.run(
            max_iterations=max_iterations,
            scoring_function=self.scoring_function,
            score_threshold=score_threshold
        )

        # Verify task status
        self.assertEqual('done', task.status)
        with self.assertRaisesOPTaaSError(400, "Cannot add configurations to a completed task"):
            task.generate_configurations()

        # Verify iterations and score threshold
        results = task.get_results()
        configurations = task.get_configurations()
        self.assertEqual(task.number_of_iterations, len(results))
        self.assertEqual(task.number_of_iterations + 1, len(configurations))  # because the last config isn't used
        if score_threshold is None:
            self.assertEqual(task.number_of_iterations, max_iterations)
        else:
            self.assertLess(task.number_of_iterations, max_iterations)
            self.assertEqual(results[-1], best_result)
            self.assertGreaterEqual(best_result.score, score_threshold)
            self.assertEqual(best_pipeline.steps[0][1].get_params(),
                             task.make_pipeline(configurations[-2]).steps[0][1].get_params())

        # Verify scores
        self.assertAlmostEqual(self.scoring_function(best_pipeline), best_result.score, delta=0.05)
        for result in results:
            config = next(c for c in configurations if c.id == result.configuration)
            pipeline = task.make_pipeline(config)
            self.assertAlmostEqual(self.scoring_function(pipeline), result.score, delta=0.05)
